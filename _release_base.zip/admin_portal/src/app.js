function resolveApiBaseUrl() {
  const configured = window.MYFIXER_ADMIN_CONFIG?.API_BASE_URL;
  if (configured) return configured;

  const { protocol, hostname } = window.location;
  return `${protocol}//${hostname}:5000/api/v1`;
}

let API_BASE_URL = resolveApiBaseUrl();

function resolveApiHealthUrl() {
  try {
    const url = new URL(API_BASE_URL);
    url.pathname = url.pathname.replace(/\/api\/v1\/?$/, '/api/health');
    if (!url.pathname.endsWith('/api/health')) url.pathname = '/api/health';
    url.search = '';
    url.hash = '';
    return url.toString();
  } catch {
    return API_BASE_URL.replace(/\/api\/v1\/?$/, '/api/health');
  }
}

function resolveApiEnvironment() {
  try {
    const url = new URL(API_BASE_URL);
    const host = url.hostname.toLowerCase();
    if (host === 'localhost' || host === '127.0.0.1' || host === '::1') return 'Local';
    if (host.includes('staging') || host.includes('stage') || host.includes('test') || host.includes('dev')) return 'Staging';
    return 'Production';
  } catch {
    return 'API';
  }
}

const state = {
  token: localStorage.getItem('myfixer_admin_token') || '',
  user: JSON.parse(localStorage.getItem('myfixer_admin_user') || 'null'),
  activeView: 'overview',
  authView: new URLSearchParams(window.location.search).has('resetToken') ? 'reset' : 'login',
  authMessage: '',
  loading: false,
  error: '',
  idleWarning: '',
  apiHealth: {
    status: 'checking',
    environment: resolveApiEnvironment(),
    responseMs: null,
    checkedAt: null,
    message: 'Checking API connection',
  },
  revealedClientContacts: {},
  revealTimers: {},
  collectionOperationFilters: {
    countryCode: '',
    city: '',
    area: '',
    collectionType: '',
    status: '',
    preferredDay: '',
  },
  notificationFilters: {
    status: '',
    channel: '',
    type: '',
    user: '',
    from: '',
    to: '',
  },
  data: {
    overview: null,
    clients: [],
    clientsContactAccess: false,
    technicians: [],
    bookings: [],
    managedCollections: [],
    managedCollectionReminders: [],
    collectionOperations: {
      jobs: [],
      metrics: {},
      calendar: {},
      meta: {},
    },
    notifications: [],
    notificationCounts: [],
    notificationMeta: {
      statuses: [],
      channels: [],
      enabledChannels: [],
      disabledChannels: [],
      types: [],
    },
    managedCollectionSubscriptions: {
      plans: [],
      subscriptions: [],
      invoices: [],
      reports: {},
      meta: {},
    },
    quotes: [],
    invoices: [],
    ledger: [],
    settlements: [],
    promotions: [],
    promotionMeta: {
      discountTypes: [],
      statuses: [],
    },
    markets: [],
    adminUsers: [],
    auditLogs: [],
    marketMeta: {
      availableStatuses: [],
      availablePaymentProviders: [],
      defaultServiceCategories: [],
      serviceDefinitions: [],
      availableMarkets: [],
    },
    adminMeta: {
      roles: [],
      permissionsByRole: {},
    },
  },
  selectedBooking: null,
};

const views = [
  { id: 'overview', label: 'Overview', icon: 'O', permission: 'overview.read' },
  { id: 'clients', label: 'Clients', icon: 'C', permission: 'overview.read' },
  { id: 'technicians', label: 'Technicians', icon: 'T', permission: 'technicians.read' },
  { id: 'bookings', label: 'Bookings', icon: 'B', permission: 'bookings.read' },
  { id: 'managedCollections', label: 'Managed Collection', icon: 'M', permission: 'bookings.read' },
  { id: 'collectionOperations', label: 'Collection Operations', icon: 'C', permission: 'bookings.read' },
  { id: 'notifications', label: 'Notifications', icon: 'N', permission: 'bookings.read' },
  { id: 'subscriptions', label: 'Subscriptions', icon: 'R', permission: 'finance.read' },
  { id: 'quotes', label: 'Quotes', icon: 'Q', permission: 'bookings.read' },
  { id: 'invoices', label: 'Invoices', icon: '$', permission: 'finance.read' },
  { id: 'settlements', label: 'Settlements', icon: 'P', permission: 'finance.read' },
  { id: 'promotions', label: 'Promotions', icon: '%', permission: 'finance.read' },
  { id: 'ledger', label: 'Wallet Ledger', icon: 'L', permission: 'finance.read' },
  { id: 'adminUsers', label: 'Admin Users', icon: 'A', permission: 'admins.read' },
  { id: 'settings', label: 'Settings', icon: 'S', permission: 'markets.read' },
  { id: 'auditLogs', label: 'Audit Logs', icon: 'H', permission: 'admins.read' },
];

const app = document.getElementById('app');

const rolePermissions = {
  SUPER_ADMIN: ['*'],
  OPERATIONS_MANAGER: ['overview.read', 'bookings.read', 'bookings.update', 'technicians.read', 'clients.contact.read', 'settings.read'],
  DISPATCHER: ['overview.read', 'bookings.read', 'bookings.update'],
  FINANCE_ADMIN: ['overview.read', 'finance.read', 'settings.read'],
  SUPPORT_AGENT: ['overview.read', 'bookings.read', 'technicians.read', 'clients.contact.read'],
  TECHNICIAN_REVIEWER: ['overview.read', 'technicians.read', 'technicians.review'],
  MARKET_MANAGER: ['overview.read', 'markets.read', 'markets.update', 'settings.read'],
  READ_ONLY_ADMIN: ['overview.read', 'bookings.read', 'technicians.read', 'finance.read', 'markets.read', 'admins.read', 'settings.read'],
};

const SERVICE_ACTIVATION_PERMISSION = 'markets.services.activate';
const CLIENT_CONTACT_PERMISSION = 'clients.contact.read';
const CLIENT_CONTACT_REVEAL_SECONDS = 15;
const IDLE_TIMEOUT_MS = 8 * 60 * 1000;
const IDLE_WARNING_MS = 60 * 1000;
const API_HEALTH_INTERVAL_MS = 60 * 1000;
const API_HEALTH_SLOW_MS = 1500;
const API_HEALTH_TIMEOUT_MS = 5000;
let idleWarningTimer = null;
let idleLogoutTimer = null;
let clockTimer = null;
let apiHealthTimer = null;

const FALLBACK_COUNTRIES = [
  ['ZA', 'South Africa'], ['GH', 'Ghana'], ['NG', 'Nigeria'], ['KE', 'Kenya'], ['UG', 'Uganda'], ['TZ', 'Tanzania'], ['RW', 'Rwanda'], ['ZM', 'Zambia'],
  ['US', 'United States'], ['GB', 'United Kingdom'], ['CA', 'Canada'], ['AU', 'Australia'], ['NZ', 'New Zealand'], ['IE', 'Ireland'],
  ['BW', 'Botswana'], ['NA', 'Namibia'], ['ZW', 'Zimbabwe'], ['MW', 'Malawi'], ['MZ', 'Mozambique'], ['AO', 'Angola'], ['CD', 'Congo - Kinshasa'],
  ['ET', 'Ethiopia'], ['EG', 'Egypt'], ['MA', 'Morocco'], ['CI', "Cote d'Ivoire"], ['SN', 'Senegal'], ['IN', 'India'], ['AE', 'United Arab Emirates'],
];

function hasPermission(permission) {
  if (!permission) return true;
  const adminRole = state.user?.adminRole || 'READ_ONLY_ADMIN';
  const permissions = new Set([...(rolePermissions[adminRole] || []), ...(state.user?.adminPermissions || [])]);
  return permissions.has('*') || permissions.has(permission);
}

function visibleViews() {
  return views.filter((view) => hasPermission(view.permission));
}

function canMutate(permission) {
  return hasPermission(permission) && state.user?.adminRole !== 'READ_ONLY_ADMIN';
}

function queryStringFrom(params = {}) {
  const search = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && String(value).trim()) {
      search.set(key, String(value).trim());
    }
  });
  const query = search.toString();
  return query ? `?${query}` : '';
}

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function formatMoney(amount, currency = '') {
  if (typeof amount !== 'number') return '-';
  try {
    return new Intl.NumberFormat('en', {
      style: 'currency',
      currency,
      currencyDisplay: 'narrowSymbol',
    }).format(amount);
  } catch {
    return `${currency} ${amount.toFixed(2)}`;
  }
}

function getCountryOptions() {
  const source = FALLBACK_COUNTRIES;
  const knownMarkets = new Map([
    ...state.data.markets.map((market) => {
      const view = getMarketView(market);
      return [view.countryCode, { name: view.countryName || view.countryCode, currency: view.currency || '' }];
    }),
    ...state.data.marketMeta.availableMarkets.map((market) => {
      const view = getMarketView(market);
      const countryCode = view.countryCode || market.countryCode || '';
      return [countryCode, { name: view.countryName || market.countryName || countryCode, currency: view.currency || market.currency || '' }];
    }),
  ]);

  return source
    .map(([code, name]) => ({
      code,
      name: knownMarkets.get(code)?.name || name,
      currency: knownMarkets.get(code)?.currency || '',
      supported: knownMarkets.has(code),
      label: `${knownMarkets.get(code)?.name || name} (${code})${knownMarkets.has(code) ? '' : ' - not configured'}`,
    }))
    .sort((a, b) => a.name.localeCompare(b.name));
}

function renderCountryOptions(selected = '') {
  return getCountryOptions()
    .map((country) => `<option value="${escapeHtml(country.code)}" data-currency="${escapeHtml(country.currency || '')}" ${country.code === selected ? 'selected' : ''}>${escapeHtml(country.label)}</option>`)
    .join('');
}

function moneyFromMinor(minor, currency = 'ZAR') {
  if (typeof minor !== 'number') return '-';
  return formatMoney(minor / 100, currency);
}

function getMoney(record, decimalField, minorField, currency = 'ZAR') {
  if (typeof record?.[decimalField] === 'number') {
    return formatMoney(record[decimalField], currency);
  }

  if (typeof record?.[minorField] === 'number') {
    return moneyFromMinor(record[minorField], currency);
  }

  return '-';
}

function getMarketView(market = {}) {
  return {
    countryCode: market.identity?.countryCode || market.countryCode || '',
    countryName: market.identity?.countryName || market.countryName || '',
    currency: market.identity?.currency || market.currency || '',
    status: market.identity?.status || market.status || (market.identity?.enabled ?? market.enabled ? 'ACTIVE' : 'DISABLED'),
    enabled: market.identity?.enabled ?? market.enabled,
    defaultCalloutFee: typeof market.pricing?.defaultCalloutFeeMinor === 'number'
      ? market.pricing.defaultCalloutFeeMinor / 100
      : typeof market.pricing?.defaultCalloutFee === 'number'
        ? market.pricing.defaultCalloutFee
      : market.defaultCalloutFee || 0,
    platformCommissionBps: market.pricing?.platformCommissionBps ?? market.platformCommissionBps ?? 0,
    taxLabel: market.pricing?.taxLabel || market.taxLabel || '',
    serviceCategories: market.coverage?.serviceCategories || market.serviceCategories || [],
    supportedCities: market.coverage?.supportedCities || market.supportedCities || [],
    cityServiceAvailability: market.coverage?.cityServiceAvailability || market.cityServiceAvailability || [],
    paymentProviders: market.payments?.paymentProviders || market.paymentProviders || [],
    providerSettings: market.payments?.providerSettings || market.paymentProviderSettings || [],
    supportEmail: market.support?.email || market.supportEmail || '',
    supportPhone: market.support?.phone || market.supportPhone || '',
    supportWhatsapp: market.support?.whatsapp || market.supportWhatsapp || '',
    supportEscalationEmail: market.support?.escalationEmail || market.supportEscalationEmail || '',
    hasCustomSettings: market.hasCustomSettings,
  };
}

function serviceKeyFrom(value) {
  return String(value || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}

function labelFromServiceKey(serviceKey) {
  return String(serviceKey || '')
    .split('_')
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ');
}

function formatTechnicianServices(services = []) {
  const labels = normalizeServiceEntries(services)
    .map((service) => service.label || labelFromServiceKey(service.serviceKey))
    .filter(Boolean);
  return labels.length ? labels.join(', ') : 'No service selected';
}

function formatYearsExperience(years) {
  const value = Number(years);
  if (!Number.isFinite(value) || value <= 0) return 'No experience set';
  return `${value} ${value === 1 ? 'year' : 'years'} experience`;
}

function formatServiceRadius(radiusKm) {
  const value = Number(radiusKm);
  if (!Number.isFinite(value) || value <= 0) return 'No radius set';
  return `${value} km radius`;
}

function formatMaskedId(last4) {
  const value = String(last4 || '').trim();
  return value ? `**** ${value}` : 'Not provided';
}

function normalizeServiceEntry(entry) {
  if (typeof entry === 'string') {
    const serviceKey = serviceKeyFrom(entry);
    return serviceKey ? { serviceKey, label: labelFromServiceKey(serviceKey), status: 'ACTIVE' } : null;
  }

  const serviceKey = serviceKeyFrom(entry?.serviceKey || entry?.key || entry?.label);
  if (!serviceKey) return null;
  return {
    serviceKey,
    label: String(entry?.label || labelFromServiceKey(serviceKey)),
    status: String(entry?.status || 'ACTIVE'),
  };
}

function normalizeServiceEntries(services = [], fallback = []) {
  const source = Array.isArray(services) && services.length ? services : fallback;
  return source.map(normalizeServiceEntry).filter(Boolean);
}

function formatServiceList(services = []) {
  return normalizeServiceEntries(services)
    .map((service) => `${service.serviceKey}:${service.status}`)
    .join(', ');
}

function countStatuses(items = []) {
  return items.reduce((counts, item) => {
    const status = String(item?.status || 'ACTIVE').toUpperCase();
    counts[status] = (counts[status] || 0) + 1;
    return counts;
  }, {});
}

function statusSummaryPills(counts = {}) {
  const statuses = ['ACTIVE', 'COMING_SOON', 'PAUSED', 'DISABLED'];
  return statuses
    .filter((status) => counts[status])
    .map((status) => `<span class="status ${statusClass(status)}">${status.replace('_', ' ')} ${counts[status]}</span>`)
    .join('');
}

function marketStatusSummary(marketView) {
  const cityRows = Array.isArray(marketView.cityServiceAvailability) ? marketView.cityServiceAvailability : [];
  const countryServices = normalizeServiceEntries(marketView.serviceCategories || state.data.marketMeta.defaultServiceCategories || []);
  const cityServices = cityRows.flatMap((row) => normalizeServiceEntries(row.services || []));
  const areas = cityRows.flatMap((row) => Array.isArray(row.areas) ? row.areas : []);
  const areaServices = areas.flatMap((area) => normalizeServiceEntries(area.services || []));
  const serviceCounts = countStatuses([...countryServices, ...cityServices, ...areaServices]);
  const cityCounts = countStatuses(cityRows);
  const areaCounts = countStatuses(areas);

  return `
    <div class="market-summary-grid">
      <div>
        <span>Country</span>
        <strong class="status ${statusClass(marketView.status)}">${escapeHtml(String(marketView.status || 'DISABLED').replace('_', ' '))}</strong>
      </div>
      <div>
        <span>Services</span>
        <div class="status-chip-row">${statusSummaryPills(serviceCounts) || '<span class="status info">No services</span>'}</div>
      </div>
      <div>
        <span>Cities</span>
        <div class="status-chip-row">${statusSummaryPills(cityCounts) || '<span class="status info">No cities</span>'}</div>
      </div>
      <div>
        <span>Areas</span>
        <div class="status-chip-row">${statusSummaryPills(areaCounts) || '<span class="status info">No areas</span>'}</div>
      </div>
    </div>
  `;
}

function formatDate(value) {
  if (!value) return '-';
  return new Date(value).toLocaleString();
}

function statusClass(status) {
  const normalized = String(status || '').toLowerCase();
  if (normalized.includes('active') || normalized.includes('approved') || normalized.includes('paid') || normalized.includes('completed')) return 'good';
  if (normalized.includes('reject') || normalized.includes('fail') || normalized.includes('suspend') || normalized.includes('cancel') || normalized.includes('disabled')) return 'bad';
  if (normalized.includes('pending') || normalized.includes('unpaid') || normalized.includes('review') || normalized.includes('soon') || normalized.includes('paused')) return 'warn';
  return 'info';
}

function apiHealthStatusClass() {
  if (state.apiHealth.status === 'connected') return 'good';
  if (state.apiHealth.status === 'slow') return 'warn';
  if (state.apiHealth.status === 'unreachable') return 'bad';
  return 'info';
}

function apiHealthLabel() {
  const health = state.apiHealth || {};
  const environment = health.environment || resolveApiEnvironment();
  const response = typeof health.responseMs === 'number' ? ` (${health.responseMs}ms)` : '';
  return health.status === 'unreachable'
    ? `${environment} API Unreachable`
    : health.status === 'slow'
      ? `${environment} API Slow${response}`
      : health.status === 'connected'
        ? `${environment} API Connected${response}`
        : `${environment} API Checking`;
}

function renderApiHealthBadge() {
  const health = state.apiHealth || {};
  const label = apiHealthLabel();
  const title = health.message || label;
  return `<span id="api-health-badge" class="status ${apiHealthStatusClass()}" title="${escapeHtml(title)}">${escapeHtml(label)}</span>`;
}

function updateTopbarIndicators() {
  const clock = document.getElementById('topbar-clock');
  if (clock) clock.textContent = state.currentTime || '';

  const badge = document.getElementById('api-health-badge');
  if (badge) {
    const label = apiHealthLabel();
    badge.className = `status ${apiHealthStatusClass()}`;
    badge.textContent = label;
    badge.title = state.apiHealth.message || label;
  }
}

async function checkApiHealth({ shouldRender = true } = {}) {
  const healthUrl = resolveApiHealthUrl();
  const startedAt = performance.now();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), API_HEALTH_TIMEOUT_MS);

  try {
    const response = await fetch(healthUrl, {
      cache: 'no-store',
      signal: controller.signal,
      headers: { Accept: 'application/json' },
    });
    const responseMs = Math.round(performance.now() - startedAt);

    state.apiHealth = {
      status: response.ok && responseMs <= API_HEALTH_SLOW_MS ? 'connected' : response.ok ? 'slow' : 'unreachable',
      environment: resolveApiEnvironment(),
      responseMs,
      checkedAt: new Date().toISOString(),
      message: response.ok
        ? `Health check passed in ${responseMs}ms at ${healthUrl}`
        : `Health check failed with HTTP ${response.status} at ${healthUrl}`,
    };
  } catch (error) {
    state.apiHealth = {
      status: 'unreachable',
      environment: resolveApiEnvironment(),
      responseMs: null,
      checkedAt: new Date().toISOString(),
      message: error?.name === 'AbortError'
        ? `Health check timed out after ${API_HEALTH_TIMEOUT_MS}ms at ${healthUrl}`
        : `Health check could not reach ${healthUrl}`,
    };
  } finally {
    clearTimeout(timeout);
  }

  if (shouldRender && state.token) updateTopbarIndicators();
}

function startApiHealthTimer() {
  if (apiHealthTimer) return;
  void checkApiHealth();
  apiHealthTimer = setInterval(() => {
    void checkApiHealth();
  }, API_HEALTH_INTERVAL_MS);
}

function stopApiHealthTimer() {
  if (!apiHealthTimer) return;
  clearInterval(apiHealthTimer);
  apiHealthTimer = null;
}

async function api(path, options = {}) {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    cache: 'no-store',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      ...(state.token ? { Authorization: `Bearer ${state.token}` } : {}),
      ...(options.headers || {}),
    },
  });

  let body = null;
  try {
    body = await response.json();
  } catch {
    body = null;
  }

  if (!response.ok) {
    if (response.status === 401 || response.status === 403) {
      state.error = body?.message || 'Your session is no longer authorized for this action.';
      if (response.status === 401) logout();
    }
    throw new Error(body?.message || body?.error || `Request failed with ${response.status}`);
  }

  return body;
}

async function login(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const email = String(form.get('email') || '').trim();
  const password = String(form.get('password') || '');
  const errorBox = document.querySelector('[data-login-error]');

  try {
    state.loading = true;
    errorBox.textContent = '';
    const result = await api('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });

    if (String(result.user?.role || '').toUpperCase() !== 'ADMIN') {
      state.token = '';
      state.user = null;
      localStorage.removeItem('myfixer_admin_token');
      localStorage.removeItem('myfixer_admin_user');
      throw new Error('This account is not an internal admin account.');
    }

    state.token = result.token;
    state.user = result.user;
    localStorage.setItem('myfixer_admin_token', result.token);
    localStorage.setItem('myfixer_admin_user', JSON.stringify(result.user));
    if (result.user?.mustChangePassword) {
      state.authView = 'changePassword';
      render();
      return;
    }
    await loadAllData();
    resetIdleTimer();
    render();
  } catch (error) {
    errorBox.textContent = error.message;
  } finally {
    state.loading = false;
  }
}

async function forgotPassword(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const email = String(form.get('email') || '').trim();
  const messageBox = document.querySelector('[data-auth-message]');
  const errorBox = document.querySelector('[data-login-error]');

  try {
    state.loading = true;
    if (messageBox) messageBox.textContent = '';
    if (errorBox) errorBox.textContent = '';
    const result = await api('/auth/forgot-password', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
    state.authMessage = result.message || 'If this email exists, reset instructions have been sent.';
    if (messageBox) messageBox.textContent = state.authMessage;
  } catch (error) {
    if (errorBox) errorBox.textContent = error.message;
  } finally {
    state.loading = false;
  }
}

async function resetPassword(event) {
  event.preventDefault();
  const params = new URLSearchParams(window.location.search);
  const form = new FormData(event.currentTarget);
  const email = String(form.get('email') || params.get('email') || '').trim();
  const token = String(form.get('token') || params.get('resetToken') || '');
  const password = String(form.get('password') || '');
  const confirmPassword = String(form.get('confirmPassword') || '');
  const messageBox = document.querySelector('[data-auth-message]');
  const errorBox = document.querySelector('[data-login-error]');

  if (password !== confirmPassword) {
    if (errorBox) errorBox.textContent = 'Passwords do not match.';
    return;
  }

  try {
    state.loading = true;
    if (messageBox) messageBox.textContent = '';
    if (errorBox) errorBox.textContent = '';
    const result = await api('/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify({ email, token, password }),
    });
    state.authMessage = result.message || 'Password reset complete. You can now sign in.';
    if (messageBox) messageBox.textContent = state.authMessage;
    state.authView = 'login';
    window.history.replaceState({}, document.title, window.location.pathname);
    render();
  } catch (error) {
    if (errorBox) errorBox.textContent = error.message;
  } finally {
    state.loading = false;
  }
}

async function changePassword(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const currentPassword = String(form.get('currentPassword') || '');
  const newPassword = String(form.get('newPassword') || '');
  const confirmPassword = String(form.get('confirmPassword') || '');
  const errorBox = document.querySelector('[data-login-error]');

  if (newPassword !== confirmPassword) {
    if (errorBox) errorBox.textContent = 'New passwords do not match.';
    return;
  }

  try {
    state.loading = true;
    if (errorBox) errorBox.textContent = '';
    const result = await api('/auth/change-password', {
      method: 'POST',
      body: JSON.stringify({ currentPassword, newPassword, forced: true }),
    });
    state.token = result.token;
    state.user = result.user;
    state.authView = 'login';
    localStorage.setItem('myfixer_admin_token', result.token);
    localStorage.setItem('myfixer_admin_user', JSON.stringify(result.user));
    await loadAllData();
    resetIdleTimer();
    render();
  } catch (error) {
    if (errorBox) errorBox.textContent = error.message;
  } finally {
    state.loading = false;
  }
}

function logout() {
  state.token = '';
  state.user = null;
  state.idleWarning = '';
  state.revealedClientContacts = {};
  Object.values(state.revealTimers || {}).forEach((timer) => clearTimeout(timer));
  state.revealTimers = {};
  localStorage.removeItem('myfixer_admin_token');
  localStorage.removeItem('myfixer_admin_user');
  clearIdleTimers();
  stopClockTimer();
  stopApiHealthTimer();
  render();
}

async function loadAllData() {
  state.loading = true;
  state.error = '';

  try {
    const requests = {
      overview: hasPermission('overview.read') ? api('/admin/overview') : Promise.resolve({ overview: null }),
      clients: hasPermission('overview.read')
        ? api('/admin/clients?limit=200').catch(() => ({ clients: [] }))
        : Promise.resolve({ clients: [] }),
      technicians: hasPermission('technicians.read') ? api('/admin/technicians') : Promise.resolve({ technicians: [] }),
      bookings: hasPermission('bookings.read') ? api('/admin/bookings?limit=100') : Promise.resolve({ bookings: [] }),
      managedCollections: hasPermission('bookings.read') ? api('/admin/managed-collections') : Promise.resolve({ profiles: [], reminders: [] }),
      collectionOperations: hasPermission('bookings.read') ? api(`/admin/collection-operations${queryStringFrom(state.collectionOperationFilters)}`) : Promise.resolve({ jobs: [], metrics: {}, calendar: {}, meta: {} }),
      notifications: hasPermission('bookings.read') ? api(`/admin/notifications${queryStringFrom(state.notificationFilters)}`) : Promise.resolve({ notifications: [], counts: [], meta: {} }),
      subscriptions: hasPermission('finance.read') ? api('/admin/managed-collection-subscriptions') : Promise.resolve({ plans: [], subscriptions: [], invoices: [], reports: {}, meta: {} }),
      quotes: hasPermission('bookings.read') ? api('/admin/quotes?limit=100') : Promise.resolve({ quotes: [] }),
      invoices: hasPermission('finance.read') ? api('/admin/invoices?limit=100') : Promise.resolve({ invoices: [] }),
      settlements: hasPermission('finance.read') ? api('/admin/settlements') : Promise.resolve({ settlements: [] }),
      promotions: hasPermission('finance.read') ? api('/admin/promotions') : Promise.resolve({ promotions: [], discountTypes: [], statuses: [] }),
      ledger: hasPermission('finance.read') ? api('/admin/wallet-transactions?limit=100') : Promise.resolve({ transactions: [] }),
      markets: hasPermission('markets.read') ? api('/admin/markets') : Promise.resolve({ markets: [], availableStatuses: [], availablePaymentProviders: [], defaultServiceCategories: [], availableMarkets: [] }),
      adminUsers: hasPermission('admins.read') ? api('/admin/users') : Promise.resolve({ admins: [], roles: [], permissionsByRole: {} }),
      auditLogs: hasPermission('admins.read') ? api('/admin/audit-logs?limit=100') : Promise.resolve({ logs: [] }),
    };

    const [overview, clients, technicians, bookings, managedCollections, collectionOperations, notifications, subscriptions, quotes, invoices, settlements, promotions, ledger, markets, adminUsers, auditLogs] = await Promise.all(Object.values(requests));

    state.data.overview = overview.overview;
    state.data.clients = clients.clients || [];
    state.data.clientsContactAccess = hasPermission(CLIENT_CONTACT_PERMISSION);
    state.data.technicians = technicians.technicians || [];
    state.data.bookings = bookings.bookings || [];
    state.data.managedCollections = managedCollections.profiles || [];
    state.data.managedCollectionReminders = managedCollections.reminders || [];
    state.data.collectionOperations = {
      jobs: collectionOperations.jobs || [],
      metrics: collectionOperations.metrics || {},
      calendar: collectionOperations.calendar || {},
      meta: collectionOperations.meta || {},
    };
    state.data.notifications = notifications.notifications || [];
    state.data.notificationCounts = notifications.counts || [];
    state.data.notificationMeta = {
      statuses: notifications.meta?.statuses || [],
      channels: notifications.meta?.channels || [],
      enabledChannels: notifications.meta?.enabledChannels || [],
      disabledChannels: notifications.meta?.disabledChannels || [],
      types: notifications.meta?.types || [],
    };
    state.data.managedCollectionSubscriptions = {
      plans: subscriptions.plans || [],
      subscriptions: subscriptions.subscriptions || [],
      invoices: subscriptions.invoices || [],
      reports: subscriptions.reports || {},
      meta: subscriptions.meta || {},
    };
    state.data.quotes = quotes.quotes || [];
    state.data.invoices = invoices.invoices || [];
    state.data.settlements = settlements.settlements || [];
    state.data.promotions = promotions.promotions || [];
    state.data.promotionMeta = {
      discountTypes: promotions.discountTypes || [],
      statuses: promotions.statuses || [],
    };
    state.data.ledger = ledger.transactions || [];
    state.data.markets = markets.markets || [];
    state.data.marketMeta = {
      availableStatuses: markets.availableStatuses || [],
    availablePaymentProviders: markets.availablePaymentProviders || [],
    defaultServiceCategories: markets.defaultServiceCategories || [],
    serviceDefinitions: markets.serviceDefinitions || [],
    availableMarkets: markets.availableMarkets || [],
  };
    state.data.adminUsers = adminUsers.admins || [];
    state.data.adminMeta = {
      roles: adminUsers.roles || [],
      permissionsByRole: adminUsers.permissionsByRole || {},
    };
    state.data.auditLogs = auditLogs.logs || [];

    const allowedViews = visibleViews();
    if (!allowedViews.some((view) => view.id === state.activeView)) {
      state.activeView = allowedViews[0]?.id || 'overview';
    }
  } finally {
    state.loading = false;
  }
}

async function refresh() {
  const button = document.querySelector('[data-refresh]');
  if (button) button.textContent = 'Refreshing...';
  try {
    await checkApiHealth({ shouldRender: false });
    await loadAllData();
    render();
  } catch (error) {
    alert(error.message);
  }
}

async function reviewTechnician(id, status) {
  if (!canMutate('technicians.review')) {
    alert('You do not have permission to review technicians.');
    return;
  }
  if (!confirm(`Confirm technician status change to ${status}?`)) return;
  const rejectionReason = status === 'REJECTED' ? prompt('Reason for rejection?') || '' : '';
  try {
    await api(`/admin/technicians/${id}/review`, {
      method: 'PATCH',
      body: JSON.stringify({ status, rejectionReason }),
    });
    await refresh();
  } catch (error) {
    alert(error.message);
  }
}

async function reviewTechnicianProfilePhoto(id, status) {
  if (!canMutate('technicians.review')) {
    alert('You do not have permission to review technician photos.');
    return;
  }
  const rejectionReason = status === 'REJECTED' ? prompt('Reason for photo rejection?') || '' : '';
  if (!confirm(`Confirm technician profile photo status change to ${status}?`)) return;
  try {
    await api(`/admin/technicians/${id}/profile-photo`, {
      method: 'PATCH',
      body: JSON.stringify({ status, rejectionReason }),
    });
    await refresh();
  } catch (error) {
    alert(error.message);
  }
}

async function openBooking(id) {
  try {
    const result = await api(`/admin/bookings/${id}`);
    state.selectedBooking = result;
    render();
  } catch (error) {
    alert(error.message);
  }
}

async function saveMarket(event, countryCode) {
  event.preventDefault();
  if (!canMutate('markets.update')) {
    alert('You do not have permission to update market settings.');
    return;
  }
  const formElement = event.currentTarget;
  const form = new FormData(formElement);
  const formCountryCode = String(form.get('countryCode') || '').trim();
  const customCountryCode = String(form.get('customCountryCode') || '').trim().toUpperCase();
  const selectedCountryCode = countryCode || customCountryCode || (formCountryCode === '__CUSTOM__' ? '' : formCountryCode);
  if (!selectedCountryCode) {
    alert('Please choose a country to add.');
    return;
  }

  const paymentProviderSettings = collectPaymentProviderRows(formElement);
  const cityServiceAvailability = collectCityServiceRows(formElement);
  const paymentProviders = paymentProviderSettings.map((row) => row.provider);
  const supportedCities = cityServiceAvailability.map((row) => row.city);
  const serviceCategoryMap = new Map();
  cityServiceAvailability
    .flatMap((row) => row.services || [])
    .forEach((service) => {
      const normalized = normalizeServiceEntry(service);
      if (normalized) serviceCategoryMap.set(normalized.serviceKey, normalized);
    });
  const serviceCategories = Array.from(serviceCategoryMap.values());
  const taxLabel = form.get('taxLabel');
  const supportWhatsapp = form.get('supportWhatsapp');
  const supportEscalationEmail = form.get('supportEscalationEmail');

  const payload = {
    countryName: String(form.get('countryName') || '').trim(),
    status: String(form.get('status') || 'DISABLED'),
    currency: String(form.get('currency') || ''),
    defaultCalloutFee: Number(form.get('defaultCalloutFee') || 0),
    platformCommissionBps: Math.round(Number(form.get('commissionPercent') || 0) * 100),
    taxLabel: taxLabel === null ? undefined : String(taxLabel).trim(),
    supportedCities,
    serviceCategories,
    cityServiceAvailability,
    paymentProviders,
    paymentProviderSettings,
    supportEmail: String(form.get('supportEmail') || ''),
    supportPhone: String(form.get('supportPhone') || ''),
    supportWhatsapp: supportWhatsapp === null ? undefined : String(supportWhatsapp),
    supportEscalationEmail: supportEscalationEmail === null ? undefined : String(supportEscalationEmail),
    identity: {
      countryName: String(form.get('countryName') || '').trim(),
      status: String(form.get('status') || 'DISABLED'),
      currency: String(form.get('currency') || ''),
    },
    pricing: {
      defaultCalloutFeeMinor: Math.round(Number(form.get('defaultCalloutFee') || 0) * 100),
      platformCommissionBps: Math.round(Number(form.get('commissionPercent') || 0) * 100),
      taxLabel: taxLabel === null ? undefined : String(taxLabel).trim(),
    },
    coverage: {
      supportedCities,
      serviceCategories,
      cityServiceAvailability,
    },
    payments: {
      paymentProviders,
      providerSettings: paymentProviderSettings,
    },
    support: {
      email: String(form.get('supportEmail') || ''),
      phone: String(form.get('supportPhone') || ''),
      whatsapp: supportWhatsapp === null ? undefined : String(supportWhatsapp),
      escalationEmail: supportEscalationEmail === null ? undefined : String(supportEscalationEmail),
    },
  };

  try {
    await api(`/admin/markets/${selectedCountryCode}`, {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
    event.currentTarget.reset();
    await refresh();
  } catch (error) {
    alert(error.message);
  }
}

function collectCityServiceRows(form) {
  return Array.from(form.querySelectorAll('[data-city-service-row]'))
    .map((row) => {
      const services = Array.from(row.querySelectorAll('[data-service-entry-row]'))
        .map((serviceRow) => ({
          serviceKey: serviceKeyFrom(serviceRow.querySelector('[data-service-key]')?.value || ''),
          label: serviceRow.querySelector('[data-service-label]')?.value.trim() || '',
          status: serviceRow.querySelector('[data-service-status]')?.value || 'ACTIVE',
        }))
        .filter((service) => service.serviceKey)
        .map((service) => ({
          ...service,
          label: service.label || labelFromServiceKey(service.serviceKey),
        }));
      const legacyServices = String(row.querySelector('[data-city-services]')?.value || '')
        .split(',')
        .map((item) => item.trim())
        .filter(Boolean)
        .map(normalizeServiceEntry)
        .filter(Boolean);
      const areas = Array.from(row.querySelectorAll('[data-area-entry-row]'))
        .map((areaRow) => ({
          name: areaRow.querySelector('[data-area-name]')?.value.trim() || '',
          status: areaRow.querySelector('[data-area-status]')?.value || 'ACTIVE',
          services: String(areaRow.querySelector('[data-area-services]')?.value || '')
            .split(',')
            .map((item) => {
              const [rawKey, rawStatus] = item.split(':').map((part) => part.trim());
              const serviceKey = serviceKeyFrom(rawKey);
              return serviceKey
                ? { serviceKey, label: labelFromServiceKey(serviceKey), status: rawStatus || 'ACTIVE' }
                : null;
            })
            .filter(Boolean),
        }))
        .filter((area) => area.name);
      return {
        city: row.querySelector('[data-city]')?.value.trim() || '',
        status: row.querySelector('[data-city-status]')?.value || 'ACTIVE',
        services: services.length ? services : legacyServices,
        areas,
      };
    })
    .filter((row) => row.city);
}

function collectPaymentProviderRows(form) {
  return Array.from(form.querySelectorAll('[data-provider-row]'))
    .map((row, index) => ({
      provider: row.querySelector('[data-provider]')?.value.trim().toUpperCase() || '',
      status: row.querySelector('[data-provider-status]')?.value || 'DISABLED',
      methods: String(row.querySelector('[data-provider-methods]')?.value || '')
        .split(',')
        .map((item) => item.trim())
        .filter(Boolean),
      priority: Number(row.querySelector('[data-provider-priority]')?.value || index + 1),
      payoutEnabled: Boolean(row.querySelector('[data-provider-payout]')?.checked),
      configReference: row.querySelector('[data-provider-config]')?.value.trim() || '',
    }))
    .filter((row) => row.provider);
}

async function createAdminUser(event) {
  event.preventDefault();
  if (!canMutate('admins.create')) {
    alert('You do not have permission to create admin users.');
    return;
  }
  const form = new FormData(event.currentTarget);
  const payload = {
    name: String(form.get('name') || '').trim(),
    email: String(form.get('email') || '').trim(),
    phone: String(form.get('phone') || '').trim(),
    adminRole: String(form.get('adminRole') || 'READ_ONLY_ADMIN'),
    adminPermissions: [
      ...(form.get('canActivateServices') === 'on' ? [SERVICE_ACTIVATION_PERMISSION] : []),
      ...(form.get('canViewClientContact') === 'on' ? [CLIENT_CONTACT_PERMISSION] : []),
    ],
    countryCode: String(form.get('countryCode') || 'ZA'),
    location: { city: String(form.get('city') || 'Head Office') },
  };

  try {
    const result = await api('/admin/users', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    alert(result.onboardingEmailSent
      ? 'User created and onboarding email sent.'
      : 'User created. Onboarding email was not sent; check ADMIN_PORTAL_URL, RESEND_API_KEY, and RESEND_FROM_EMAIL.');
    event.currentTarget.reset();
    await refresh();
  } catch (error) {
    alert(error.message);
  }
}

async function updateAdminUser(id, patch) {
  if (!canMutate('admins.update')) {
    alert('You do not have permission to update admin users.');
    return;
  }
  if (!confirm('Confirm this admin account change?')) return;
  try {
    await api(`/admin/users/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(patch),
    });
    await refresh();
  } catch (error) {
    alert(error.message);
  }
}

function renderLogin() {
  const params = new URLSearchParams(window.location.search);
  const resetToken = params.get('resetToken') || '';
  const resetEmail = params.get('email') || '';
  const authForm = state.authView === 'changePassword'
    ? `
        <form class="login-card" onsubmit="changePassword(event)">
          <div class="login-heading">
            <span class="eyebrow">First sign-in</span>
            <h2>Change temporary password</h2>
            <p>Create a permanent password before opening the internal dashboard.</p>
          </div>
          <label>Temporary Password</label>
          <input name="currentPassword" type="password" autocomplete="current-password" required />
          <label>New Password</label>
          <input name="newPassword" type="password" autocomplete="new-password" minlength="8" required />
          <label>Confirm New Password</label>
          <input name="confirmPassword" type="password" autocomplete="new-password" minlength="8" required />
          <p class="form-error" data-login-error></p>
          <button class="primary-button" type="submit">${state.loading ? 'Updating...' : 'Update Password'}</button>
          <button class="text-button" type="button" onclick="logout()">Sign out</button>
        </form>
      `
    : state.authView === 'forgot'
    ? `
        <form class="login-card" onsubmit="forgotPassword(event)">
          <div class="login-heading">
            <span class="eyebrow">Password reset</span>
            <h2>Reset admin access</h2>
            <p>Enter your admin email. If the account exists, reset instructions will be sent.</p>
          </div>
          <label>Email</label>
          <input name="email" type="email" autocomplete="email" required />
          <p class="form-message" data-auth-message></p>
          <p class="form-error" data-login-error></p>
          <button class="primary-button" type="submit">${state.loading ? 'Sending...' : 'Send Reset Instructions'}</button>
          <button class="text-button" type="button" onclick="setAuthView('login')">Back to sign in</button>
        </form>
      `
    : state.authView === 'reset'
      ? `
          <form class="login-card" onsubmit="resetPassword(event)">
            <div class="login-heading">
              <span class="eyebrow">Set new password</span>
              <h2>Create a new password</h2>
              <p>Use the email that received the reset link.</p>
            </div>
            <input name="token" type="hidden" value="${escapeHtml(resetToken)}" />
            <label>Email</label>
            <input name="email" type="email" autocomplete="email" value="${escapeHtml(resetEmail)}" required />
            <label>New Password</label>
            <input name="password" type="password" autocomplete="new-password" minlength="6" required />
            <label>Confirm Password</label>
            <input name="confirmPassword" type="password" autocomplete="new-password" minlength="6" required />
            <p class="form-message" data-auth-message></p>
            <p class="form-error" data-login-error></p>
            <button class="primary-button" type="submit">${state.loading ? 'Resetting...' : 'Reset Password'}</button>
            <button class="text-button" type="button" onclick="setAuthView('login')">Back to sign in</button>
          </form>
        `
      : `
          <form class="login-card" onsubmit="login(event)">
            <div class="login-heading">
              <span class="eyebrow">Admin access</span>
              <h2>Sign in to operations</h2>
              <p>Internal staff only. Customer and technician accounts are blocked from this portal.</p>
            </div>

            <label>Email</label>
            <input name="email" type="email" autocomplete="username" required />

            <label>Password</label>
            <input name="password" type="password" autocomplete="current-password" required />

            <div class="login-row">
              <button class="text-button" type="button" onclick="setAuthView('forgot')">Forgot password?</button>
            </div>
            <p class="form-error" data-login-error></p>
            <p class="form-message" data-auth-message>${escapeHtml(state.authMessage)}</p>
            <button class="primary-button" type="submit">${state.loading ? 'Signing in...' : 'Sign In'}</button>
          </form>
        `;

  app.innerHTML = `
    <main class="login-page">
      <section class="login-media" aria-label="MyFixer operations image">
        <div class="media-overlay">
          <div class="brand-lockup">
            <img
              src="https://res.cloudinary.com/dz7dr3wku/image/upload/v1783803342/myfixer_logo_dlan5o.png"
              alt="MyFixer logo"
              class="brand-logo"
            />
            <div>
              <h1>MyFixer Back Office</h1>
              <p>Centralized platform for managing operations, markets, workforce, dispatch, payments, and provider trust across the MyFixer ecosystem.</p>
            </div>
          </div>
          <div class="media-stats">
            <div><strong>Secure</strong><span>Internal access only</span></div>
            <div><strong>Live</strong><span>Connected API data</span></div>
            <div><strong>Audit</strong><span>Tracked admin actions</span></div>
          </div>
        </div>
      </section>

      <section class="login-panel">
        ${authForm}
      </section>
    </main>
  `;
}

function setAuthView(view) {
  state.authView = view;
  state.authMessage = '';
  if (view === 'login') {
    window.history.replaceState({}, document.title, window.location.pathname);
  }
  render();
}

function formatClockTime() {
  const now = new Date();
  return new Intl.DateTimeFormat('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  }).format(now);
}

function startClockTimer() {
  if (clockTimer) return;
  state.currentTime = formatClockTime();
  clockTimer = setInterval(() => {
    state.currentTime = formatClockTime();
    updateTopbarIndicators();
  }, 60 * 1000);
}

function stopClockTimer() {
  if (!clockTimer) return;
  clearInterval(clockTimer);
  clockTimer = null;
}

function renderShell() {
  startClockTimer();
  startApiHealthTimer();
  const navViews = visibleViews();
  const activeView = navViews.find((view) => view.id === state.activeView) || navViews[0];
  if (activeView && activeView.id !== state.activeView) state.activeView = activeView.id;

  app.innerHTML = `
    <div class="admin-shell">
      <aside class="sidebar">
        <div class="sidebar-brand">
          <img
            src="https://res.cloudinary.com/dz7dr3wku/image/upload/v1783803342/myfixer_logo_dlan5o.png"
            alt="MyFixer logo"
            class="brand-logo small"
          />
        </div>
        <div class="sidebar-user">
          <strong>${escapeHtml(state.user?.adminRole || 'ADMIN')}</strong>
          <span>${escapeHtml(state.user?.email || '')}</span>
        </div>
        <nav>
          ${navViews.map((view) => `
            <button class="nav-item ${state.activeView === view.id ? 'active' : ''}" onclick="setView('${view.id}')">
              ${view.label}
            </button>
          `).join('')}
        </nav>
      </aside>

      <main class="workspace">
        <header class="topbar">
          <div>
            <span class="eyebrow">Operations console</span>
            <h1>${navViews.find((view) => view.id === state.activeView)?.label || 'Overview'}</h1>
          </div>
          <div class="topbar-actions">
            ${renderApiHealthBadge()}
            <span id="topbar-clock" class="topbar-clock">${escapeHtml(state.currentTime || '')}</span>
            <button class="ghost-button" data-refresh onclick="refresh()" ${state.loading ? 'disabled' : ''}>${state.loading ? 'Refreshing...' : 'Refresh'}</button>
            <button class="danger-button" onclick="logout()">Sign Out</button>
          </div>
        </header>
        <section class="content" aria-busy="${state.loading ? 'true' : 'false'}">
          ${state.loading ? '<div class="notice">Loading live operations data...</div>' : ''}
          ${state.error ? `<div class="notice error">${escapeHtml(state.error)}</div>` : ''}
          ${state.idleWarning ? `<div class="notice warn">${escapeHtml(state.idleWarning)}</div>` : ''}
          ${renderActiveView()}
        </section>
      </main>
      ${state.selectedBooking ? renderBookingDrawer() : ''}
    </div>
  `;
}

function clearIdleTimers() {
  if (idleWarningTimer) clearTimeout(idleWarningTimer);
  if (idleLogoutTimer) clearTimeout(idleLogoutTimer);
  idleWarningTimer = null;
  idleLogoutTimer = null;
}

function resetIdleTimer() {
  clearIdleTimers();
  if (!state.token) return;

  if (state.idleWarning) {
    state.idleWarning = '';
    render();
  }

  idleWarningTimer = setTimeout(() => {
    if (!state.token) return;
    state.idleWarning = 'Security timeout: you will be signed out in 60 seconds unless activity continues.';
    render();
  }, IDLE_TIMEOUT_MS - IDLE_WARNING_MS);

  idleLogoutTimer = setTimeout(() => {
    if (!state.token) return;
    alert('You have been signed out because the admin portal was inactive.');
    logout();
  }, IDLE_TIMEOUT_MS);
}

function setupIdleSecurity() {
  ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll'].forEach((eventName) => {
    window.addEventListener(eventName, resetIdleTimer, { passive: true });
  });
  resetIdleTimer();
}

function setView(view) {
  if (!visibleViews().some((item) => item.id === view)) return;
  state.activeView = view;
  state.selectedBooking = null;
  render();
}

function renderActiveView() {
  if (!visibleViews().some((view) => view.id === state.activeView)) {
    return '<section class="panel"><p class="empty">You do not have access to this section.</p></section>';
  }
  if (state.activeView === 'overview') return renderOverview();
  if (state.activeView === 'clients') return renderClients();
  if (state.activeView === 'technicians') return renderTechnicians();
  if (state.activeView === 'bookings') return renderBookings();
  if (state.activeView === 'managedCollections') return renderManagedCollections();
  if (state.activeView === 'collectionOperations') return renderCollectionOperations();
  if (state.activeView === 'notifications') return renderNotifications();
  if (state.activeView === 'subscriptions') return renderSubscriptions();
  if (state.activeView === 'quotes') return renderQuotes();
  if (state.activeView === 'invoices') return renderInvoices();
  if (state.activeView === 'settlements') return renderSettlements();
  if (state.activeView === 'promotions') return renderPromotions();
  if (state.activeView === 'ledger') return renderLedger();
  if (state.activeView === 'adminUsers') return renderAdminUsers();
  if (state.activeView === 'settings') return renderSettings();
  if (state.activeView === 'auditLogs') return renderAuditLogs();
  return '';
}

function getOverviewNumber(primary, fallback = 0) {
  return Number.isFinite(Number(primary)) ? Number(primary) : fallback;
}

function isPendingProvider(tech = {}) {
  const status = String(tech.approvalStatus || '').toUpperCase();
  return status.includes('PENDING') || status.includes('REVIEW');
}

function isApprovedProvider(tech = {}) {
  return String(tech.approvalStatus || '').toUpperCase() === 'APPROVED';
}

function renderProviderReviewQueue() {
  const pendingProviders = (state.data.technicians || []).filter(isPendingProvider).slice(0, 5);
  if (!pendingProviders.length) return renderEmpty('No provider applications are waiting for review.');

  return `
    <div class="overview-list">
      ${pendingProviders.map((tech) => {
        const user = tech.userId || {};
        const serviceLabel = formatTechnicianServices(tech.serviceCategories || []);
        const location = [tech.city, tech.countryCode].filter(Boolean).join(', ') || '-';
        return `
          <article class="overview-row">
            <div>
              <strong>${escapeHtml(user.name || 'Provider')}</strong>
              <span>${escapeHtml(serviceLabel)}</span>
              <small>${escapeHtml(location)} • ${escapeHtml(formatYearsExperience(tech.yearsExperience))}</small>
            </div>
            <span class="status ${statusClass(tech.approvalStatus)}">${escapeHtml(tech.approvalStatus || 'PENDING')}</span>
          </article>
        `;
      }).join('')}
    </div>
  `;
}

function renderMarketCoverage() {
  const markets = (state.data.markets || []).map(getMarketView);
  if (!markets.length) return renderEmpty('No launch markets have been configured yet.');

  return `
    <div class="coverage-grid">
      ${markets.slice(0, 6).map((market) => {
        const activeCities = (market.cityServiceAvailability || [])
          .filter((city) => String(city.status || '').toUpperCase() === 'ACTIVE' || city.enabled === true);
        const serviceCount = normalizeServiceEntries(market.serviceCategories || []).length;
        const providerCount = (market.providerSettings || market.paymentProviders || []).length;
        return `
          <article class="coverage-tile">
            <div class="coverage-tile-head">
              <strong>${escapeHtml(market.countryName || market.countryCode || 'Market')}</strong>
              <span class="status ${statusClass(market.status)}">${escapeHtml(market.status || '-')}</span>
            </div>
            <span>${escapeHtml(market.currency || '-')} • ${activeCities.length} active ${activeCities.length === 1 ? 'city' : 'cities'}</span>
            <span>${serviceCount} ${serviceCount === 1 ? 'service' : 'services'} • ${providerCount} payment ${providerCount === 1 ? 'provider' : 'providers'}</span>
          </article>
        `;
      }).join('')}
    </div>
  `;
}

function renderPlatformReadiness() {
  const markets = (state.data.markets || []).map(getMarketView);
  const hasActiveMarket = markets.some((market) => String(market.status || '').toUpperCase() === 'ACTIVE');
  const hasPaymentProvider = markets.some((market) => (market.paymentProviders || []).length || (market.providerSettings || []).length);
  const pendingProviders = (state.data.technicians || []).filter(isPendingProvider).length;
  const unpaidInvoices = getOverviewNumber(state.data.overview?.unpaidInvoices, state.data.invoices.filter((invoice) => String(invoice.status || '').toUpperCase() === 'UNPAID').length);
  const checks = [
    {
      label: 'Backend API',
      value: apiHealthLabel(),
      status: state.apiHealth.status === 'connected' ? 'good' : state.apiHealth.status === 'slow' ? 'warn' : 'bad',
    },
    {
      label: 'Active markets',
      value: hasActiveMarket ? `${markets.filter((market) => String(market.status || '').toUpperCase() === 'ACTIVE').length} active` : 'Needs setup',
      status: hasActiveMarket ? 'good' : 'warn',
    },
    {
      label: 'Payment providers',
      value: hasPaymentProvider ? 'Configured' : 'Needs provider',
      status: hasPaymentProvider ? 'good' : 'warn',
    },
    {
      label: 'Provider reviews',
      value: pendingProviders ? `${pendingProviders} pending` : 'Clear',
      status: pendingProviders ? 'warn' : 'good',
    },
    {
      label: 'Unpaid invoices',
      value: unpaidInvoices ? `${unpaidInvoices} open` : 'Clear',
      status: unpaidInvoices ? 'warn' : 'good',
    },
  ];

  return `
    <div class="readiness-list">
      ${checks.map((check) => `
        <div class="readiness-row">
          <span>${escapeHtml(check.label)}</span>
          <strong>${escapeHtml(check.value)}</strong>
          <span class="status ${check.status}">${check.status === 'good' ? 'OK' : check.status === 'warn' ? 'WATCH' : 'ISSUE'}</span>
        </div>
      `).join('')}
    </div>
  `;
}

function renderRecentAdminActivity() {
  const logs = (state.data.auditLogs || []).slice(0, 5);
  if (!logs.length) return renderEmpty('No admin actions have been recorded yet.');

  return `
    <div class="overview-list">
      ${logs.map((log) => {
        const action = log.event?.action || log.action || '-';
        const actorEmail = log.actor?.email || log.actorEmail || '-';
        const resourceType = log.event?.resourceType || log.resourceType || '-';
        return `
          <article class="overview-row">
            <div>
              <strong>${escapeHtml(action)}</strong>
              <span>${escapeHtml(actorEmail)}</span>
              <small>${escapeHtml(resourceType)} • ${escapeHtml(formatDate(log.createdAt))}</small>
            </div>
          </article>
        `;
      }).join('')}
    </div>
  `;
}

function renderOverview() {
  const overview = state.data.overview || {};
  const fallbackTotalProviders = state.data.technicians.length;
  const auditAction = hasPermission('admins.read')
    ? '<button class="ghost-button compact" onclick="setView(\'auditLogs\')">Open</button>'
    : '<span>Read only</span>';
  const marketAction = hasPermission('markets.read')
    ? '<button class="ghost-button compact" onclick="setView(\'settings\')">Open</button>'
    : '<span>Read only</span>';
  const technicianAction = hasPermission('technicians.read')
    ? '<button class="ghost-button compact" onclick="setView(\'technicians\')">Open</button>'
    : '<span>Read only</span>';
  const cards = [
    { label: 'Active bookings', value: overview.activeBookings || 0 },
    { label: 'Pending providers', value: overview.pendingTechnicians || 0, view: 'technicians' },
    { label: 'Approved providers', value: overview.approvedTechnicians || 0, view: 'technicians' },
    { label: 'Clients', value: overview.clients || 0, view: 'clients' },
    { label: 'Pending quotes', value: overview.pendingQuotes || 0 },
    { label: 'Unpaid invoices', value: overview.unpaidInvoices || 0 },
    { label: 'Completed jobs', value: overview.completedBookings || 0 },
    { label: 'Total providers', value: getOverviewNumber(overview.totalTechnicians, fallbackTotalProviders), view: 'technicians' },
  ];

  return `
    <div class="metric-grid">
      ${cards.map((card) => `
        <article class="metric-card ${card.view ? 'clickable' : ''}" ${card.view ? `onclick="setView('${card.view}')"` : ''}>
          <span>${card.label}</span>
          <strong>${card.value}</strong>
        </article>
      `).join('')}
    </div>
    <div class="two-column">
      <section class="panel">
        <div class="panel-header"><h2>Recent Bookings</h2><span>${state.data.bookings.length} latest</span></div>
        ${renderBookingTable(state.data.bookings.slice(0, 6))}
      </section>
      <section class="panel">
        <div class="panel-header"><h2>Provider Review Queue</h2>${technicianAction}</div>
        ${renderProviderReviewQueue()}
      </section>
    </div>
    <div class="two-column">
      <section class="panel">
        <div class="panel-header"><h2>Revenue Snapshot</h2></div>
        ${renderCurrencyTotals(overview.totalsByCurrency || {})}
      </section>
      <section class="panel">
        <div class="panel-header"><h2>Platform Readiness</h2><span>${escapeHtml(resolveApiEnvironment())}</span></div>
        ${renderPlatformReadiness()}
      </section>
    </div>
    <div class="two-column wide-right">
      <section class="panel">
        <div class="panel-header"><h2>Recent Admin Activity</h2>${auditAction}</div>
        ${renderRecentAdminActivity()}
      </section>
      <section class="panel">
        <div class="panel-header"><h2>Market Coverage</h2>${marketAction}</div>
        ${renderMarketCoverage()}
      </section>
    </div>
  `;
}

function renderClients() {
  const rows = state.data.clients || [];
  const contactAccess = state.data.clientsContactAccess === true;
  return `
    <section class="panel">
      <div class="panel-header">
        <div>
          <h2>Clients</h2>
          <span>${rows.length} customer accounts - contact details masked by default</span>
        </div>
      </div>
      ${renderGenericTable(rows, ['Name', 'Contact', 'Country', 'Location', 'Status', 'Verified', 'Joined', 'Actions'], (client) => {
        const revealed = state.revealedClientContacts?.[client._id];
        return [
        `${escapeHtml(client.name || 'Unnamed client')}<span>${escapeHtml(client._id || '')}</span>`,
        `${escapeHtml(revealed?.email || client.email || '-')}<span>${escapeHtml(revealed?.phone || client.phone || '-')}</span>`,
        escapeHtml(client.countryCode || '-'),
        `${escapeHtml(client.location?.city || '-')}<span>${escapeHtml(client.location?.area || '')}</span>`,
        `<span class="status ${statusClass(client.accountStatus || 'ACTIVE')}">${escapeHtml(client.accountStatus || 'ACTIVE')}</span>`,
        client.isEmailVerified ? '<span class="status good">EMAIL VERIFIED</span>' : '<span class="status warn">EMAIL PENDING</span>',
        formatDate(client.createdAt),
        contactAccess
          ? `<button class="ghost-button compact" onclick="${revealed ? `hideClientContact('${client._id}')` : `revealClientContact('${client._id}')`}">${revealed ? 'Hide Contact' : 'View Contact'}</button>${revealed ? '<span>Auto-hides soon</span>' : ''}`
          : '<span class="status info">Masked</span>',
      ];
      })}
    </section>
  `;
}

async function revealClientContact(clientId) {
  if (!clientId || !hasPermission(CLIENT_CONTACT_PERMISSION)) {
    alert('You do not have permission to view client contact details.');
    return;
  }

  try {
    const result = await api(`/admin/clients/${clientId}/contact`);
    state.revealedClientContacts = {
      ...state.revealedClientContacts,
      [clientId]: result.contact,
    };

    if (state.revealTimers?.[clientId]) clearTimeout(state.revealTimers[clientId]);
    state.revealTimers = {
      ...state.revealTimers,
      [clientId]: setTimeout(() => hideClientContact(clientId), (result.contact?.expiresInSeconds || CLIENT_CONTACT_REVEAL_SECONDS) * 1000),
    };
    render();
  } catch (error) {
    alert(error.message || 'Unable to reveal client contact.');
  }
}

function hideClientContact(clientId) {
  if (state.revealTimers?.[clientId]) clearTimeout(state.revealTimers[clientId]);
  const nextContacts = { ...(state.revealedClientContacts || {}) };
  const nextTimers = { ...(state.revealTimers || {}) };
  delete nextContacts[clientId];
  delete nextTimers[clientId];
  state.revealedClientContacts = nextContacts;
  state.revealTimers = nextTimers;
  render();
}

function renderCurrencyTotals(totals) {
  const entries = Object.entries(totals);
  if (!entries.length) return renderEmpty('No ledger activity yet.');
  return `
    <div class="currency-list">
      ${entries.map(([currency, total]) => `
        <div class="currency-row">
          <strong>${currency}</strong>
          <span>Commission ${getMoney(total, 'commission', 'commissionMinor', currency)}</span>
          <span>Tech pending ${getMoney(total, 'technicianPending', 'technicianPendingMinor', currency)}</span>
          <span>Client due ${getMoney(total, 'clientDue', 'clientDueMinor', currency)}</span>
        </div>
      `).join('')}
    </div>
  `;
}

function renderTechnicians() {
  const rows = state.data.technicians;
  const canReview = canMutate('technicians.review');
  return `
    <section class="panel">
      <div class="panel-header">
        <h2>Technician Applications</h2>
        <span>${rows.length} records</span>
      </div>
      <div class="card-list">
        ${rows.map((tech) => {
          const user = tech.userId || {};
          const photoUrl = tech.documents?.profilePhotoUrl || user.profilePhotoUrl || '';
          const photoStatus = tech.documents?.profilePhotoStatus || 'NOT_SUBMITTED';
          const serviceLabel = formatTechnicianServices(tech.serviceCategories || []);
          const experienceLabel = formatYearsExperience(tech.yearsExperience);
          const radiusLabel = formatServiceRadius(tech.serviceRadiusKm);
          const providerLabel = tech.businessName || 'Independent provider';
          const transportLabel = tech.vehicleType || 'Transport not set';
          const idLabel = formatMaskedId(tech.idNumberLast4);
          return `
            <article class="review-card">
              <div class="technician-review-main">
                <a class="technician-photo" href="${escapeHtml(photoUrl || '#')}" target="_blank" rel="noopener noreferrer">
                  ${photoUrl
                    ? `<img src="${escapeHtml(photoUrl)}" alt="${escapeHtml(user.name || 'Technician')} profile photo" />`
                    : '<span>No photo</span>'}
                </a>
                <div>
                  <div class="row-title">
                    ${escapeHtml(user.name || 'Provider')}
                    <span class="status ${statusClass(tech.approvalStatus)}">${escapeHtml(tech.approvalStatus)}</span>
                    <span class="status ${photoStatus === 'VERIFIED' ? 'success' : photoStatus === 'REJECTED' ? 'danger' : 'info'}">Photo ${escapeHtml(photoStatus)}</span>
                  </div>
                  <p>${escapeHtml(user.email || '-')} - ${escapeHtml(user.phone || '-')} - ${escapeHtml(tech.city)}, ${escapeHtml(tech.countryCode)}</p>
                  <div class="technician-summary">
                    <strong>${escapeHtml(serviceLabel)}</strong>
                    <span>${escapeHtml(experienceLabel)} • ${escapeHtml(radiusLabel)}</span>
                    <span>${escapeHtml(providerLabel)} • ${escapeHtml(transportLabel)}</span>
                    <span>ID / Registration: ${escapeHtml(idLabel)}</span>
                  </div>
                  ${tech.review?.rejectionReason ? `<p class="warning-text">${escapeHtml(tech.review.rejectionReason)}</p>` : ''}
                </div>
              </div>
              ${canReview ? `
                <div class="review-actions">
                  <button class="success-button" onclick="reviewTechnicianProfilePhoto('${tech._id}', 'VERIFIED')" ${photoUrl ? '' : 'disabled'}>Approve Photo</button>
                  <button class="ghost-button" onclick="reviewTechnicianProfilePhoto('${tech._id}', 'REJECTED')" ${photoUrl ? '' : 'disabled'}>Reject Photo</button>
                  <button class="success-button" onclick="reviewTechnician('${tech._id}', 'APPROVED')" ${photoStatus === 'VERIFIED' ? '' : 'disabled'}>Approve</button>
                  <button class="ghost-button" onclick="reviewTechnician('${tech._id}', 'REJECTED')">Reject</button>
                  <button class="danger-button" onclick="reviewTechnician('${tech._id}', 'SUSPENDED')">Suspend</button>
                </div>
              ` : '<span class="status info">Read only</span>'}
            </article>
          `;
        }).join('') || renderEmpty('No technician applications yet.')}
      </div>
    </section>
  `;
}

function renderBookings() {
  return `
    <section class="panel">
      <div class="panel-header"><h2>Bookings</h2><span>${state.data.bookings.length} latest</span></div>
      ${renderBookingTable(state.data.bookings)}
    </section>
  `;
}

async function updateManagedCollectionReminder(id, patch) {
  if (!canMutate('bookings.update')) {
    alert('You do not have permission to update reminders.');
    return;
  }

  try {
    await api(`/admin/managed-collection-reminders/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(patch),
    });
    await refresh();
  } catch (error) {
    alert(error.message);
  }
}

function rescheduleManagedCollectionReminder(id) {
  const scheduledFor = prompt('New reminder date/time (YYYY-MM-DDTHH:mm):');
  if (!scheduledFor) return;
  updateManagedCollectionReminder(id, { scheduledFor });
}

function remindersForProfile(profileId) {
  return state.data.managedCollectionReminders.filter((reminder) => String(reminder.targetId) === String(profileId));
}

async function updateCollectionJob(id, action, extra = {}) {
  if (!canMutate('bookings.update')) {
    alert('You do not have permission to manage collection operations.');
    return;
  }

  const labels = {
    MARK_COMPLETED: 'mark this collection completed',
    MARK_MISSED: 'mark this collection missed',
    RESCHEDULE: 'reschedule this collection',
    CANCEL: 'cancel this collection',
  };

  if (!confirm(`Confirm you want to ${labels[action] || 'update this collection'}?`)) return;

  try {
    await api(`/admin/collection-jobs/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ action, ...extra }),
    });
    await refresh();
  } catch (error) {
    alert(error.message);
  }
}

function markCollectionCompleted(id) {
  const notes = prompt('Completion notes (optional):') || '';
  updateCollectionJob(id, 'MARK_COMPLETED', { notes });
}

function markCollectionMissed(id) {
  const missedReason = prompt('Reason this collection was missed?') || '';
  if (!missedReason.trim()) return;
  const notes = prompt('Additional notes (optional):') || '';
  updateCollectionJob(id, 'MARK_MISSED', { missedReason, notes });
}

function rescheduleCollectionJob(id) {
  const scheduledFor = prompt('New collection date/time (YYYY-MM-DDTHH:mm):');
  if (!scheduledFor) return;
  const notes = prompt('Reschedule notes (optional):') || '';
  updateCollectionJob(id, 'RESCHEDULE', { scheduledFor, notes });
}

function cancelCollectionJob(id) {
  const notes = prompt('Cancellation notes (optional):') || '';
  updateCollectionJob(id, 'CANCEL', { notes });
}

async function applyCollectionOperationFilters(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  state.collectionOperationFilters = {
    countryCode: String(form.get('countryCode') || '').trim(),
    city: String(form.get('city') || '').trim(),
    area: String(form.get('area') || '').trim(),
    collectionType: String(form.get('collectionType') || '').trim(),
    status: String(form.get('status') || '').trim(),
    preferredDay: String(form.get('preferredDay') || '').trim(),
  };
  await refresh();
}

async function resetCollectionOperationFilters() {
  state.collectionOperationFilters = {
    countryCode: '',
    city: '',
    area: '',
    collectionType: '',
    status: '',
    preferredDay: '',
  };
  await refresh();
}

function jobsByWindow(from, to) {
  const start = from ? new Date(from).getTime() : 0;
  const end = to ? new Date(to).getTime() : Number.MAX_SAFE_INTEGER;
  return (state.data.collectionOperations.jobs || []).filter((job) => {
    const scheduled = new Date(job.scheduledFor).getTime();
    return scheduled >= start && scheduled <= end;
  });
}

function renderCollectionJobActions(job, canUpdate) {
  if (!canUpdate || ['COMPLETED', 'MISSED', 'CANCELLED'].includes(job.status)) {
    return '<span class="status info">Read only</span>';
  }

  return `
    <div class="review-actions compact-actions">
      <button class="success-button compact" onclick="markCollectionCompleted('${job._id}')">Complete</button>
      <button class="ghost-button compact" onclick="rescheduleCollectionJob('${job._id}')">Reschedule</button>
      <button class="ghost-button compact" onclick="markCollectionMissed('${job._id}')">Missed</button>
      <button class="danger-button compact" onclick="cancelCollectionJob('${job._id}')">Cancel</button>
    </div>
  `;
}

function renderCollectionJobTable(rows, canUpdate) {
  return renderGenericTable(rows, ['Customer', 'Location', 'Schedule', 'Collection', 'Status', 'Actions'], (job) => [
    `<strong>${escapeHtml(job.customerName || 'Client')}</strong><span>${escapeHtml(job.customerEmail || '-')}</span>`,
    `${escapeHtml(job.city || '-')}<span>${escapeHtml(job.area || job.fullAddress || '')}</span>`,
    `${formatDate(job.scheduledFor)}<span>${escapeHtml(job.preferredCollectionDay || '-')}</span>`,
    `${escapeHtml(job.collectionType || '-')}<span>${escapeHtml((job.binPackage || []).join(', '))} - ${escapeHtml(job.frequency || '-')}</span>`,
    `<span class="status ${statusClass(job.status)}">${escapeHtml(job.status || '-')}</span>`,
    renderCollectionJobActions(job, canUpdate),
  ]);
}

function renderCollectionOperations() {
  const operations = state.data.collectionOperations || {};
  const jobs = operations.jobs || [];
  const metrics = operations.metrics || {};
  const calendar = operations.calendar || {};
  const meta = operations.meta || {};
  const filters = state.collectionOperationFilters || {};
  const canUpdate = canMutate('bookings.update');
  const now = new Date();
  const overdueJobs = jobs.filter((job) => {
    const scheduled = new Date(job.scheduledFor);
    return scheduled < now && ['SCHEDULED', 'ASSIGNED', 'IN_PROGRESS'].includes(job.status);
  });
  const completedJobs = jobs.filter((job) => job.status === 'COMPLETED');
  const upcomingJobs = jobs.filter((job) => {
    const scheduled = new Date(job.scheduledFor);
    return scheduled >= now && ['SCHEDULED', 'ASSIGNED', 'IN_PROGRESS'].includes(job.status);
  });
  const todayJobs = jobsByWindow(calendar.today?.from, calendar.today?.to);
  const tomorrowJobs = jobsByWindow(calendar.tomorrow?.from, calendar.tomorrow?.to);
  const weekJobs = jobsByWindow(calendar.week?.from, calendar.week?.to);
  const monthJobs = jobsByWindow(calendar.month?.from, calendar.month?.to);
  const metricCards = [
    ['Active Customers', metrics.activeCollectionCustomers || 0],
    ['Today', metrics.collectionsToday || 0],
    ['This Week', metrics.collectionsThisWeek || 0],
    ['Completed Month', metrics.completedThisMonth || 0],
    ['Missed', metrics.missedCollections || 0],
    ['Upcoming', metrics.upcomingCollections || 0],
  ];

  return `
    <section class="panel">
      <div class="panel-header"><div><h2>Filters</h2><span>Country, city, area, collection type, status, and preferred day.</span></div></div>
      <form class="settings-form" onsubmit="applyCollectionOperationFilters(event)">
        <div class="form-grid">
          <div>
            <label>Country</label>
            <input name="countryCode" value="${escapeHtml(filters.countryCode || '')}" placeholder="ZA, ZM, GH" />
          </div>
          <div>
            <label>City</label>
            <input name="city" value="${escapeHtml(filters.city || '')}" placeholder="Lusaka" />
          </div>
          <div>
            <label>Area</label>
            <input name="area" value="${escapeHtml(filters.area || '')}" placeholder="Neighbourhood" />
          </div>
          <div>
            <label>Collection Type</label>
            <select name="collectionType">
              <option value="">All</option>
              ${(meta.collectionTypes || ['GENERAL_WASTE']).map((type) => `<option value="${type}" ${filters.collectionType === type ? 'selected' : ''}>${type}</option>`).join('')}
            </select>
          </div>
          <div>
            <label>Status</label>
            <select name="status">
              <option value="">All</option>
              ${(meta.statuses || ['SCHEDULED', 'ASSIGNED', 'IN_PROGRESS', 'COMPLETED', 'MISSED', 'CANCELLED']).map((status) => `<option value="${status}" ${filters.status === status ? 'selected' : ''}>${status}</option>`).join('')}
            </select>
          </div>
          <div>
            <label>Preferred Day</label>
            <select name="preferredDay">
              <option value="">All</option>
              ${(meta.days || ['MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY', 'SUNDAY']).map((day) => `<option value="${day}" ${filters.preferredDay === day ? 'selected' : ''}>${day}</option>`).join('')}
            </select>
          </div>
        </div>
        <div class="review-actions">
          <button class="primary-button compact" type="submit">Apply Filters</button>
          <button class="ghost-button compact" type="button" onclick="resetCollectionOperationFilters()">Reset</button>
        </div>
      </form>
    </section>
    <div class="metric-grid">
      ${metricCards.map(([label, value]) => `
        <article class="metric-card">
          <span>${label}</span>
          <strong>${value}</strong>
        </article>
      `).join('')}
    </div>
    <section class="panel">
      <div class="panel-header"><div><h2>Today's Collections</h2><span>${todayJobs.length} scheduled</span></div></div>
      ${renderCollectionJobTable(todayJobs, canUpdate)}
    </section>
    <section class="panel">
      <div class="panel-header"><div><h2>Tomorrow's Collections</h2><span>${tomorrowJobs.length} scheduled</span></div></div>
      ${renderCollectionJobTable(tomorrowJobs, canUpdate)}
    </section>
    <section class="panel">
      <div class="panel-header"><div><h2>This Week</h2><span>${weekJobs.length} scheduled</span></div></div>
      ${renderCollectionJobTable(weekJobs, canUpdate)}
    </section>
    <section class="panel">
      <div class="panel-header"><div><h2>Overdue & Missed</h2><span>${overdueJobs.length + jobs.filter((job) => job.status === 'MISSED').length} records</span></div></div>
      ${renderCollectionJobTable([...overdueJobs, ...jobs.filter((job) => job.status === 'MISSED')], canUpdate)}
    </section>
    <section class="panel">
      <div class="panel-header"><div><h2>Monthly Calendar</h2><span>${monthJobs.length} collections</span></div></div>
      ${renderCollectionJobTable(monthJobs, canUpdate)}
    </section>
    <section class="panel">
      <div class="panel-header"><div><h2>Upcoming Collections</h2><span>${upcomingJobs.length} scheduled</span></div></div>
      ${renderCollectionJobTable(upcomingJobs.slice(0, 100), canUpdate)}
    </section>
    <section class="panel">
      <div class="panel-header"><div><h2>Completed Collections</h2><span>${completedJobs.length} records</span></div></div>
      ${renderCollectionJobTable(completedJobs.slice(0, 100), canUpdate)}
    </section>
  `;
}

async function applyNotificationFilters(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  state.notificationFilters = {
    status: String(form.get('status') || '').trim(),
    channel: String(form.get('channel') || '').trim(),
    type: String(form.get('type') || '').trim(),
    user: String(form.get('user') || '').trim(),
    from: String(form.get('from') || '').trim(),
    to: String(form.get('to') || '').trim(),
  };
  await refresh();
}

async function resetNotificationFilters() {
  state.notificationFilters = {
    status: '',
    channel: '',
    type: '',
    user: '',
    from: '',
    to: '',
  };
  await refresh();
}

async function processDueNotifications() {
  if (!canMutate('bookings.update')) {
    alert('You do not have permission to process notifications.');
    return;
  }
  try {
    await api('/admin/notifications/process-due', { method: 'POST' });
    await refresh();
  } catch (error) {
    alert(error.message);
  }
}

async function retryNotification(id) {
  if (!canMutate('bookings.update')) {
    alert('You do not have permission to retry notifications.');
    return;
  }
  try {
    await api(`/admin/notifications/${id}/retry`, { method: 'POST' });
    await refresh();
  } catch (error) {
    alert(error.message);
  }
}

async function cancelNotification(id) {
  if (!canMutate('bookings.update')) {
    alert('You do not have permission to cancel notifications.');
    return;
  }
  if (!confirm('Cancel this scheduled notification?')) return;
  try {
    await api(`/admin/notifications/${id}/cancel`, { method: 'POST' });
    await refresh();
  } catch (error) {
    alert(error.message);
  }
}

function renderNotifications() {
  const rows = state.data.notifications || [];
  const meta = state.data.notificationMeta || {};
  const filters = state.notificationFilters || {};
  const counts = Object.fromEntries((state.data.notificationCounts || []).map((item) => [item._id, item.count]));
  const canUpdate = canMutate('bookings.update');
  const metricCards = ['PENDING', 'SCHEDULED', 'SENT', 'FAILED', 'CANCELLED', 'READ'].map((status) => [status, counts[status] || 0]);

  return `
    <section class="panel">
      <div class="panel-header">
        <div><h2>Notification Center</h2><span>In-App and Email are enabled. Push, SMS, and WhatsApp are foundation-only.</span></div>
        ${canUpdate ? '<button class="primary-button compact" onclick="processDueNotifications()">Process Due</button>' : ''}
      </div>
      <form class="settings-form" onsubmit="applyNotificationFilters(event)">
        <div class="form-grid">
          <div>
            <label>Status</label>
            <select name="status">
              <option value="">All</option>
              ${(meta.statuses || []).map((status) => `<option value="${status}" ${filters.status === status ? 'selected' : ''}>${status}</option>`).join('')}
            </select>
          </div>
          <div>
            <label>Channel</label>
            <select name="channel">
              <option value="">All</option>
              ${(meta.channels || []).map((channel) => `<option value="${channel}" ${filters.channel === channel ? 'selected' : ''}>${channel}</option>`).join('')}
            </select>
          </div>
          <div>
            <label>Type</label>
            <select name="type">
              <option value="">All</option>
              ${(meta.types || []).map((type) => `<option value="${type}" ${filters.type === type ? 'selected' : ''}>${type}</option>`).join('')}
            </select>
          </div>
          <div>
            <label>User</label>
            <input name="user" value="${escapeHtml(filters.user || '')}" placeholder="email or user id" />
          </div>
          <div>
            <label>From</label>
            <input name="from" type="date" value="${escapeHtml(filters.from || '')}" />
          </div>
          <div>
            <label>To</label>
            <input name="to" type="date" value="${escapeHtml(filters.to || '')}" />
          </div>
        </div>
        <div class="review-actions">
          <button class="primary-button compact" type="submit">Apply Filters</button>
          <button class="ghost-button compact" type="button" onclick="resetNotificationFilters()">Reset</button>
        </div>
      </form>
    </section>
    <div class="metric-grid">
      ${metricCards.map(([label, value]) => `
        <article class="metric-card">
          <span>${label}</span>
          <strong>${value}</strong>
        </article>
      `).join('')}
    </div>
    <section class="panel">
      <div class="panel-header"><h2>Notifications</h2><span>${rows.length} latest</span></div>
      ${renderGenericTable(rows, ['Recipient', 'Message', 'Channel', 'Status', 'Schedule', 'Actions'], (notification) => [
        `<strong>${escapeHtml(notification.recipient?.name || 'User')}</strong><span>${escapeHtml(notification.recipient?.email || '-')}</span>`,
        `<strong>${escapeHtml(notification.title || '-')}</strong><span>${escapeHtml(notification.message || '')}</span>`,
        `${escapeHtml(notification.channel || '-')}<span>${escapeHtml(notification.type || '-')}</span>`,
        `<span class="status ${statusClass(notification.status)}">${escapeHtml(notification.status || '-')}</span>${notification.lastError ? `<span>${escapeHtml(notification.lastError)}</span>` : ''}`,
        `${formatDate(notification.scheduledAt)}<span>Sent ${formatDate(notification.sentAt)}</span>`,
        canUpdate
          ? `
              ${notification.status === 'FAILED' ? `<button class="ghost-button compact" onclick="retryNotification('${notification._id}')">Retry</button>` : ''}
              ${['PENDING', 'SCHEDULED'].includes(notification.status) ? `<button class="danger-button compact" onclick="cancelNotification('${notification._id}')">Cancel</button>` : ''}
            `
          : '<span class="status info">Read only</span>',
      ])}
    </section>
  `;
}

async function createSubscriptionPlan(event) {
  event.preventDefault();
  if (!canMutate('markets.update')) {
    alert('You do not have permission to manage subscription plans.');
    return;
  }
  const form = new FormData(event.currentTarget);
  const payload = {
    name: String(form.get('name') || '').trim(),
    description: String(form.get('description') || '').trim(),
    countryCode: String(form.get('countryCode') || '').trim().toUpperCase(),
    currency: String(form.get('currency') || '').trim().toUpperCase(),
    price: Number(form.get('price') || 0),
    billingFrequency: String(form.get('billingFrequency') || 'MONTHLY'),
    collectionFrequency: String(form.get('collectionFrequency') || 'WEEKLY'),
    collectionType: String(form.get('collectionType') || 'GENERAL_WASTE'),
    status: String(form.get('status') || 'ACTIVE'),
    binPackage: String(form.get('binPackage') || '')
      .split(',')
      .map((item) => item.trim().toUpperCase())
      .filter(Boolean),
  };

  try {
    await api('/admin/managed-collection-subscription-plans', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    event.currentTarget.reset();
    syncPromotionCurrency(event.currentTarget.elements.countryCode);
    await refresh();
  } catch (error) {
    alert(error.message);
  }
}

async function generateSubscriptionInvoices() {
  if (!canMutate('bookings.update') && !hasPermission('finance.read')) {
    alert('You do not have permission to generate subscription invoices.');
    return;
  }
  try {
    const result = await api('/admin/managed-collection-subscriptions/generate-invoices', { method: 'POST' });
    alert(`${result.invoices?.length || 0} subscription invoices generated.`);
    await refresh();
  } catch (error) {
    alert(error.message);
  }
}

function renderSubscriptions() {
  const data = state.data.managedCollectionSubscriptions || {};
  const plans = data.plans || [];
  const subscriptions = data.subscriptions || [];
  const invoices = data.invoices || [];
  const reports = data.reports || {};
  const meta = data.meta || {};
  const canManagePlans = canMutate('markets.update');
  const mrr = (reports.monthlyRecurringRevenue || [])
    .map((row) => `${row._id}: ${moneyFromMinor(row.monthlyRecurringRevenueMinor || 0, row._id)}`)
    .join(', ') || '-';
  const cards = [
    ['MRR', mrr],
    ['Active', reports.activeSubscriptions || 0],
    ['Renewals', reports.renewals || 0],
    ['Cancelled', reports.cancelled || 0],
    ['Overdue', reports.overdue || 0],
    ['Churn', `${Math.round((reports.churn || 0) * 100)}%`],
  ];

  return `
    <div class="metric-grid">
      ${cards.map(([label, value]) => `
        <article class="metric-card">
          <span>${label}</span>
          <strong>${value}</strong>
        </article>
      `).join('')}
    </div>
    <section class="panel">
      <div class="panel-header">
        <div><h2>Renewals & Billing</h2><span>Invoices are generated only. Automatic charging is disabled.</span></div>
        <button class="primary-button compact" onclick="generateSubscriptionInvoices()">Generate Due Invoices</button>
      </div>
      ${renderGenericTable(invoices, ['Invoice', 'Customer', 'Amount', 'Status', 'Due'], (invoice) => [
        escapeHtml(invoice.invoiceNumber || '-'),
        escapeHtml(invoice.customerId || '-'),
        moneyFromMinor(invoice.amountMinor, invoice.currency),
        `<span class="status ${statusClass(invoice.status)}">${escapeHtml(invoice.status || '-')}</span>`,
        formatDate(invoice.dueAt),
      ])}
    </section>
    <section class="panel">
      <div class="panel-header"><div><h2>Plans</h2><span>${plans.length} configured</span></div></div>
      ${renderGenericTable(plans, ['Plan', 'Price', 'Billing', 'Collection', 'Status'], (plan) => [
        `<strong>${escapeHtml(plan.name || '-')}</strong><span>${escapeHtml(plan.description || '')}</span>`,
        moneyFromMinor(plan.priceMinor, plan.currency),
        `${escapeHtml(plan.billingFrequency || '-')}<span>${escapeHtml(plan.countryCode || '-')}</span>`,
        `${escapeHtml(plan.collectionFrequency || '-')}<span>${escapeHtml((plan.binPackage || []).join(', '))} - ${escapeHtml(plan.collectionType || '-')}</span>`,
        `<span class="status ${statusClass(plan.status)}">${escapeHtml(plan.status || '-')}</span>`,
      ])}
    </section>
    ${canManagePlans ? `
      <section class="panel">
        <div class="panel-header"><div><h2>Create Plan</h2><span>Managed Collection Services only.</span></div></div>
        <form class="settings-form" onsubmit="createSubscriptionPlan(event)">
          <label>Plan Name</label>
          <input name="name" required placeholder="General Waste Monthly" />
          <label>Description</label>
          <input name="description" placeholder="Weekly pickup with red, green, and blue bins" />
          <div class="form-grid">
            <div><label>Country</label><input name="countryCode" required placeholder="ZM" /></div>
            <div><label>Currency</label><input name="currency" required placeholder="ZMW" /></div>
            <div><label>Price</label><input name="price" type="number" min="0" step="0.01" required /></div>
            <div>
              <label>Billing Frequency</label>
              <select name="billingFrequency">${(meta.billingFrequencies || ['WEEKLY', 'MONTHLY', 'QUARTERLY', 'YEARLY']).map((item) => `<option value="${item}">${item}</option>`).join('')}</select>
            </div>
            <div>
              <label>Collection Frequency</label>
              <select name="collectionFrequency">${(meta.collectionFrequencies || ['WEEKLY', 'TWICE_WEEKLY', 'MONTHLY']).map((item) => `<option value="${item}">${item}</option>`).join('')}</select>
            </div>
            <div>
              <label>Status</label>
              <select name="status">${(meta.planStatuses || ['ACTIVE', 'PAUSED', 'DISABLED']).map((item) => `<option value="${item}">${item}</option>`).join('')}</select>
            </div>
          </div>
          <input name="collectionType" type="hidden" value="GENERAL_WASTE" />
          <label>Bin Package</label>
          <input name="binPackage" value="RED, GREEN, BLUE" />
          <button class="primary-button compact" type="submit">Create Plan</button>
        </form>
      </section>
    ` : ''}
    <section class="panel">
      <div class="panel-header"><div><h2>Customers</h2><span>${subscriptions.length} subscriptions</span></div></div>
      ${renderGenericTable(subscriptions, ['Customer', 'Plan', 'Billing', 'Status', 'Renewal'], (subscription) => [
        `<strong>${escapeHtml(subscription.customerName || 'Client')}</strong><span>${escapeHtml(subscription.customerEmail || '-')}</span>`,
        `${escapeHtml(subscription.planName || '-')}<span>${escapeHtml(subscription.collectionType || '-')}</span>`,
        `${moneyFromMinor(subscription.priceMinor, subscription.currency)}<span>${escapeHtml(subscription.billingFrequency || '-')}</span>`,
        `<span class="status ${statusClass(subscription.status)}">${escapeHtml(subscription.status || '-')}</span>`,
        `${formatDate(subscription.renewalDate)}<span>Grace ${formatDate(subscription.gracePeriodEndsAt)}</span>`,
      ])}
    </section>
  `;
}

function renderManagedCollections() {
  const rows = state.data.managedCollections;
  const canUpdate = canMutate('bookings.update');
  return `
    <section class="panel">
      <div class="panel-header">
        <div><h2>Managed Collection Customers</h2><span>${rows.length} signups</span></div>
      </div>
      ${renderGenericTable(rows, ['Customer', 'Location', 'Collection', 'Schedule', 'Status', 'Reminders'], (profile) => {
        const reminders = remindersForProfile(profile._id);
        return [
          `<strong>${escapeHtml(profile.customerName || 'Client')}</strong><span>${escapeHtml(profile.customerEmail || '-')}</span>`,
          `${escapeHtml(profile.countryCode || '-')} - ${escapeHtml(profile.city || '-')}<span>${escapeHtml(profile.area || '')}</span>`,
          `${escapeHtml(profile.collectionType || '-')}<span>${escapeHtml((profile.binPackage || []).join(', '))} - ${escapeHtml(profile.propertyType || '-')}</span>`,
          `${escapeHtml(profile.frequency || '-')}<span>${escapeHtml(profile.preferredCollectionDay || '-')} - Next ${formatDate(profile.nextCollectionDate)}</span>`,
          `<span class="status ${statusClass(profile.status)}">${escapeHtml(profile.status || '-')}</span>`,
          reminders.length
            ? reminders.map((reminder) => `
                <div class="mini-row">
                  <span>${escapeHtml(reminder.reminderType)} - ${formatDate(reminder.scheduledFor)}</span>
                  <span class="status ${statusClass(reminder.status)}">${escapeHtml(reminder.status)}</span>
                  ${canUpdate && reminder.status !== 'CANCELLED' ? `
                    <button class="ghost-button compact" onclick="rescheduleManagedCollectionReminder('${reminder._id}')">Reschedule</button>
                    <button class="ghost-button compact" onclick="updateManagedCollectionReminder('${reminder._id}', { status: 'CANCELLED' })">Cancel</button>
                  ` : ''}
                </div>
              `).join('')
            : '<span>-</span>',
        ];
      })}
    </section>
  `;
}

function renderBookingTable(bookings) {
  if (!bookings.length) return renderEmpty('No bookings found.');
  return `
    <div class="table-wrap">
      <table>
        <thead>
          <tr><th>Job</th><th>Client</th><th>Market</th><th>Status</th><th>Value</th><th>Updated</th><th></th></tr>
        </thead>
        <tbody>
          ${bookings.map((booking) => {
            const countryCode = booking.identity?.countryCode || booking.countryCode || '-';
            const currency = booking.identity?.currency || booking.currency || 'ZAR';
            return `
              <tr>
                <td><strong>${escapeHtml(booking.applianceType || '-')}</strong><span>${escapeHtml(booking.generalArea || '-')}</span></td>
                <td>${escapeHtml(booking.customerName || '-')}</td>
                <td>${escapeHtml(countryCode)} - ${escapeHtml(currency || '-')}</td>
                <td><span class="status ${statusClass(booking.status)}">${escapeHtml(booking.status)}</span></td>
                <td>${getMoney(booking, 'price', 'priceMinor', currency)}</td>
                <td>${formatDate(booking.updatedAt)}</td>
                <td><button class="ghost-button compact" onclick="openBooking('${booking._id}')">Open</button></td>
              </tr>
            `;
          }).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function renderQuotes() {
  const quotes = state.data.quotes;
  return `
    <section class="panel">
      <div class="panel-header"><h2>Quotes & Work Orders</h2><span>${quotes.length} latest</span></div>
      ${renderGenericTable(quotes, ['Status', 'Booking', 'Technician', 'Total', 'Sent'], (quote) => [
        `<span class="status ${statusClass(quote.status)}">${escapeHtml(quote.status)}</span>`,
        escapeHtml(quote.bookingId?.applianceType || quote.bookingId || '-'),
        escapeHtml(quote.technicianId?.name || '-'),
        getMoney(quote, 'totalAmount', 'totalAmountMinor', quote.currency),
        formatDate(quote.sentAt || quote.createdAt),
      ])}
    </section>
  `;
}

function renderInvoices() {
  const invoices = state.data.invoices;
  return `
    <section class="panel">
      <div class="panel-header"><h2>Payments & Invoices</h2><span>${invoices.length} latest</span></div>
      ${renderGenericTable(invoices, ['Invoice', 'Status', 'Total', 'Commission', 'Tech Net', 'Created'], (invoice) => [
        escapeHtml(invoice.invoiceNumber),
        `<span class="status ${statusClass(invoice.status)}">${escapeHtml(invoice.status)}</span>`,
        getMoney(invoice, 'totalAmount', 'totalAmountMinor', invoice.currency),
        getMoney(invoice, 'platformCommissionAmount', 'platformCommissionAmountMinor', invoice.currency),
        getMoney(invoice, 'technicianNetAmount', 'technicianNetAmountMinor', invoice.currency),
        formatDate(invoice.createdAt),
      ])}
    </section>
  `;
}

function renderSettlements() {
  const rows = state.data.settlements || [];
  return `
    <section class="panel">
      <div class="panel-header"><h2>Settlement Centre</h2><span>${rows.length} latest</span></div>
      ${renderGenericTable(rows, ['Settlement', 'Booking', 'Currency', 'Gross', 'Commission', 'Net', 'Status', 'Payout', 'Actions'], (settlement) => [
        escapeHtml(settlement.id || settlement._id || '-'),
        escapeHtml(settlement.bookingId || '-'),
        escapeHtml(settlement.currency || '-'),
        moneyFromMinor(settlement.grossAmountMinor || 0, settlement.currency || 'ZAR'),
        moneyFromMinor(settlement.commissionAmountMinor || 0, settlement.currency || 'ZAR'),
        moneyFromMinor(settlement.netAmountMinor || 0, settlement.currency || 'ZAR'),
        `<span class="status ${statusClass(settlement.status)}">${escapeHtml(settlement.status || '-')}</span>`,
        escapeHtml(settlement.metadata?.payoutDestinationSnapshot?.maskedDestination || 'Not selected'),
        renderSettlementActions(settlement),
      ])}
    </section>
  `;
}

function renderSettlementActions(settlement) {
  const id = settlement.id || settlement._id;
  if (!id || !canMutate('finance.read')) return '<span class="status info">Read only</span>';
  const status = settlement.status || '';
  const approve = ['APPROVAL_REQUIRED', 'READY_FOR_PAYOUT', 'PAYOUT_FAILED'].includes(status)
    ? `<button class="ghost-button compact" onclick="approveSettlement('${id}')">Approve</button>`
    : '';
  const hold = !['PAID', 'PAYOUT_PROCESSING'].includes(status)
    ? `<button class="ghost-button compact" onclick="holdSettlement('${id}')">Hold</button>`
    : '';
  const release = status === 'ON_HOLD'
    ? `<button class="ghost-button compact" onclick="releaseSettlementHold('${id}')">Release</button>`
    : '';
  const retry = status === 'PAYOUT_FAILED'
    ? `<button class="ghost-button compact" onclick="retrySettlementPayout('${id}')">Retry</button>`
    : '';
  return `<div class="inline-actions">${approve}${hold}${release}${retry}</div>`;
}

async function approveSettlement(id) {
  const reason = window.prompt('Approval note for payout review');
  if (!reason) return;
  await api(`/admin/settlements/${id}/approve`, { method: 'POST', body: JSON.stringify({ reason }) });
  await loadAllData();
  render();
}

async function holdSettlement(id) {
  const reason = window.prompt('Reason for settlement hold');
  if (!reason) return;
  await api(`/admin/settlements/${id}/hold`, { method: 'POST', body: JSON.stringify({ reason }) });
  await loadAllData();
  render();
}

async function releaseSettlementHold(id) {
  const reason = window.prompt('Reason for releasing hold') || 'Reviewed';
  await api(`/admin/settlements/${id}/release-hold`, { method: 'POST', body: JSON.stringify({ reason }) });
  await loadAllData();
  render();
}

async function retrySettlementPayout(id) {
  const reason = window.prompt('Reason for payout retry') || 'Retry reviewed payout';
  await api(`/admin/settlements/${id}/retry-payout`, { method: 'POST', body: JSON.stringify({ reason }) });
  await loadAllData();
  render();
}

async function createPromotion(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const discountType = String(form.get('discountType') || 'PERCENTAGE');
  const discountValueRaw = Number(form.get('discountValue') || 0);
  const discountValue = discountType === 'FIXED_AMOUNT'
    ? Math.round(discountValueRaw * 100)
    : discountValueRaw;

  const payload = {
    code: String(form.get('code') || '').trim().toUpperCase(),
    name: String(form.get('name') || '').trim(),
    description: String(form.get('description') || '').trim(),
    status: String(form.get('status') || 'ACTIVE').toUpperCase(),
    discountType,
    discountValue,
    maxDiscountMinor: Math.round(Number(form.get('maxDiscount') || 0) * 100) || null,
    minBookingAmountMinor: Math.round(Number(form.get('minBookingAmount') || 0) * 100) || 0,
    countryCode: String(form.get('countryCode') || ''),
    currency: String(form.get('currency') || ''),
    startsAt: String(form.get('startsAt') || '') || null,
    expiresAt: String(form.get('expiresAt') || '') || null,
    usageLimit: Number(form.get('usageLimit') || 0) || null,
    perClientLimit: Number(form.get('perClientLimit') || 0) || null,
  };

  try {
    await api('/admin/promotions', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    event.currentTarget.reset();
    await refresh();
  } catch (error) {
    alert(error.message);
  }
}

function syncPromotionCurrency(select) {
  const form = select?.form;
  const currencyInput = form?.elements?.currency;
  if (!currencyInput) return;

  const selectedCurrency = select.selectedOptions?.[0]?.dataset?.currency || '';
  currencyInput.value = selectedCurrency;
  currencyInput.placeholder = selectedCurrency || 'Optional, e.g. ZAR';
}

async function updatePromotion(id, patch) {
  if (!patch || typeof patch !== 'object') return;
  try {
    await api(`/admin/promotions/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(patch),
    });
    await refresh();
  } catch (error) {
    alert(error.message);
  }
}

function renderPromotions() {
  const promotions = state.data.promotions || [];
  const discountTypes = state.data.promotionMeta.discountTypes.length
    ? state.data.promotionMeta.discountTypes
    : ['PERCENTAGE', 'FIXED_AMOUNT'];
  return `
    <div class="two-column">
      <section class="panel">
        <div class="panel-header"><h2>Promo Codes</h2><span>${promotions.length} configured</span></div>
        ${renderGenericTable(promotions, ['Code', 'Discount', 'Scope', 'Usage', 'Status', 'Actions'], (promotion) => [
          `<strong>${escapeHtml(promotion.code)}</strong><span>${escapeHtml(promotion.name || '-')}</span>`,
          promotion.discountType === 'PERCENTAGE'
            ? `${escapeHtml(promotion.discountValue)}%<span>Max ${promotion.maxDiscountMinor ? moneyFromMinor(promotion.maxDiscountMinor, promotion.currency || 'ZAR') : 'No cap'}</span>`
            : `${moneyFromMinor(promotion.discountValue, promotion.currency || 'ZAR')}<span>Fixed amount</span>`,
          `${escapeHtml(promotion.countryCode || 'All countries')}<span>${escapeHtml(promotion.currency || 'Any currency')}</span>`,
          `${promotion.usageCount || 0}<span>${promotion.usageLimit ? `of ${promotion.usageLimit}` : 'unlimited'}</span>`,
          `<span class="status ${statusClass(promotion.status)}">${escapeHtml(promotion.status)}</span>`,
          `<button class="ghost-button compact" onclick="updatePromotion('${promotion._id}', { status: '${promotion.status === 'ACTIVE' ? 'PAUSED' : 'ACTIVE'}' })">${promotion.status === 'ACTIVE' ? 'Pause' : 'Activate'}</button>`,
        ])}
      </section>
      <section class="panel">
        <div class="panel-header"><h2>Create Promo</h2><span>Uber-style client discounts</span></div>
        <form class="settings-form" onsubmit="createPromotion(event)">
          <label>Promo Code</label>
          <input name="code" required placeholder="FIXER50" />
          <label>Name</label>
          <input name="name" required placeholder="Launch discount" />
          <label>Description</label>
          <input name="description" placeholder="Optional internal note" />
          <div class="form-grid">
            <div>
              <label>Discount Type</label>
              <select name="discountType">
                ${discountTypes.map((type) => `<option value="${type}">${type}</option>`).join('')}
              </select>
            </div>
            <div>
              <label>Discount Value</label>
              <input name="discountValue" type="number" min="0" step="0.01" required placeholder="10" />
            </div>
          </div>
          <div class="form-grid">
            <div>
              <label>Status</label>
              <select name="status">
                <option value="ACTIVE">ACTIVE</option>
                <option value="PAUSED">PAUSED</option>
                <option value="EXPIRED">EXPIRED</option>
              </select>
            </div>
            <div>
              <label>Max Discount Amount</label>
              <input name="maxDiscount" type="number" min="0" step="0.01" placeholder="0 for no cap" />
            </div>
          </div>
          <div class="form-grid">
            <div>
              <label>Minimum Booking Amount</label>
              <input name="minBookingAmount" type="number" min="0" step="0.01" placeholder="0" />
            </div>
            <div>
              <label>Applies to Booking Country</label>
              <select name="countryCode" onchange="syncPromotionCurrency(this)">
                <option value="">All configured countries</option>
                ${renderCountryOptions('')}
              </select>
              <p class="setting-help tight">Checked against the booking market/location, not just the client profile.</p>
            </div>
          </div>
          <label>Currency</label>
          <input name="currency" placeholder="Optional, e.g. ZAR" />
          <p class="setting-help tight">Auto-filled from the selected country. Leave blank only for multi-currency/global promos.</p>
          <div class="form-grid">
            <div>
              <label>Starts At</label>
              <input name="startsAt" type="datetime-local" />
            </div>
            <div>
              <label>Expires At</label>
              <input name="expiresAt" type="datetime-local" />
            </div>
          </div>
          <div class="form-grid">
            <div>
              <label>Total Usage Limit</label>
              <input name="usageLimit" type="number" min="0" step="1" placeholder="0 for unlimited" />
            </div>
            <div>
              <label>Per Client Limit</label>
              <input name="perClientLimit" type="number" min="0" step="1" placeholder="0 for unlimited" />
            </div>
          </div>
          <button class="primary-button" type="submit">Create Promo</button>
        </form>
      </section>
    </div>
  `;
}

function renderLedger() {
  const rows = state.data.ledger;
  return `
    <section class="panel">
      <div class="panel-header"><h2>Wallet Ledger</h2><span>${rows.length} latest</span></div>
      ${renderGenericTable(rows, ['Type', 'Status', 'Technician', 'Amount', 'Description', 'Created'], (row) => [
        escapeHtml(row.type),
        `<span class="status ${statusClass(row.status)}">${escapeHtml(row.status)}</span>`,
        escapeHtml(row.technicianId?.name || '-'),
        getMoney(row, 'amount', 'amountMinor', row.currency),
        escapeHtml(row.description || '-'),
        formatDate(row.createdAt),
      ])}
    </section>
  `;
}

function renderAdminUsers() {
  const roles = state.data.adminMeta.roles.length ? state.data.adminMeta.roles : ['READ_ONLY_ADMIN'];
  const canCreateAdmins = canMutate('admins.create');
  const canUpdateAdmins = canMutate('admins.update');
  return `
    <div class="two-column admin-users-layout">
      <section class="panel">
        <div class="panel-header">
          <h2>Internal Staff</h2>
          <span>${state.data.adminUsers.length} users</span>
        </div>
        ${renderGenericTable(state.data.adminUsers, ['Name', 'Role', 'Status', 'Email', 'Actions'], (admin) => [
          `<strong>${escapeHtml(admin.name)}</strong><span>${escapeHtml(admin.phone || '-')}</span>`,
          `<span class="status info">${escapeHtml(admin.adminRole || 'SUPER_ADMIN')}</span>`,
          admin.isActive === false ? '<span class="status bad">INACTIVE</span>' : '<span class="status good">ACTIVE</span>',
          escapeHtml(admin.email),
          canUpdateAdmins
            ? `
              <select onchange="updateAdminUser('${admin._id}', { adminRole: this.value })">
                ${roles.map((role) => `<option value="${role}" ${role === admin.adminRole ? 'selected' : ''}>${role}</option>`).join('')}
              </select>
              ${renderServiceActivationToggle(admin)}
              ${renderClientContactToggle(admin)}
              <button class="ghost-button compact" onclick="updateAdminUser('${admin._id}', { isActive: ${admin.isActive === false ? 'true' : 'false'} })">${admin.isActive === false ? 'Activate' : 'Deactivate'}</button>
            `
            : '<span class="status info">Read only</span>',
        ])}
      </section>

      <section class="panel">
        <div class="panel-header"><h2>Create Users</h2><span>${canCreateAdmins ? 'Super admin only' : 'Admin access required'}</span></div>
        <form class="settings-form" onsubmit="${canCreateAdmins ? 'createAdminUser(event)' : 'event.preventDefault()'}">
          <label>Name</label>
          <input name="name" required placeholder="Operations Manager" ${canCreateAdmins ? '' : 'disabled'} />
          <label>Email</label>
          <input name="email" type="email" required placeholder="ops@myfixer.com" ${canCreateAdmins ? '' : 'disabled'} />
          <label>Phone</label>
          <input name="phone" required placeholder="+27000000000" ${canCreateAdmins ? '' : 'disabled'} />
          <p class="setting-help">A secure temporary password is generated automatically and sent by onboarding email.</p>
          <div class="form-grid">
            <div>
              <label>Role</label>
              <select name="adminRole" ${canCreateAdmins ? '' : 'disabled'}>
                ${roles.map((role) => `<option value="${role}">${role}</option>`).join('')}
              </select>
            </div>
            <div>
              <label>Country</label>
              <select name="countryCode" ${canCreateAdmins ? '' : 'disabled'}>
                ${renderCountryOptions('ZA')}
              </select>
            </div>
          </div>
          <label>City</label>
          <input name="city" placeholder="Head Office" ${canCreateAdmins ? '' : 'disabled'} />
          <label class="inline-check"><input name="canActivateServices" type="checkbox" ${canCreateAdmins ? '' : 'disabled'} /> Can activate market services</label>
          <label class="inline-check"><input name="canViewClientContact" type="checkbox" ${canCreateAdmins ? '' : 'disabled'} /> Can view client contact details</label>
          <button class="primary-button" type="submit" ${canCreateAdmins ? '' : 'disabled'}>${canCreateAdmins ? 'Create Users' : 'Create Users (permission required)'}</button>
          ${canCreateAdmins ? '' : '<p class="empty">Only a super admin or an admin with create permissions can add new internal staff.</p>'}
        </form>
      </section>
    </div>
    <section class="panel">
      <div class="panel-header"><h2>Role Access</h2><span>Portal visibility map</span></div>
      <div class="role-grid">
        ${roles.map((role) => `
          <article class="mini-card">
            <strong>${role}</strong>
            <p>${escapeHtml((state.data.adminMeta.permissionsByRole[role] || []).join(', ') || 'No permissions assigned')}</p>
          </article>
        `).join('')}
      </div>
    </section>
  `;
}

function renderServiceActivationToggle(admin) {
  const currentPermissions = Array.isArray(admin.adminPermissions) ? admin.adminPermissions : [];
  const hasActivation = currentPermissions.includes(SERVICE_ACTIVATION_PERMISSION);
  const nextPermissions = hasActivation
    ? currentPermissions.filter((permission) => permission !== SERVICE_ACTIVATION_PERMISSION)
    : Array.from(new Set([...currentPermissions, SERVICE_ACTIVATION_PERMISSION]));

  return `
    <button class="ghost-button compact" onclick='updateAdminUser("${admin._id}", { adminPermissions: ${JSON.stringify(nextPermissions)} })'>
      ${hasActivation ? 'Remove Service Activation' : 'Allow Service Activation'}
    </button>
  `;
}

function renderClientContactToggle(admin) {
  const currentPermissions = Array.isArray(admin.adminPermissions) ? admin.adminPermissions : [];
  const roleGrantsContact = (rolePermissions[admin.adminRole || 'READ_ONLY_ADMIN'] || []).includes(CLIENT_CONTACT_PERMISSION);
  if (roleGrantsContact) {
    return '<span class="status good">Role grants client contact</span>';
  }

  const hasContactAccess = currentPermissions.includes(CLIENT_CONTACT_PERMISSION);
  const nextPermissions = hasContactAccess
    ? currentPermissions.filter((permission) => permission !== CLIENT_CONTACT_PERMISSION)
    : Array.from(new Set([...currentPermissions, CLIENT_CONTACT_PERMISSION]));

  return `
    <button class="ghost-button compact" onclick='updateAdminUser("${admin._id}", { adminPermissions: ${JSON.stringify(nextPermissions)} })'>
      ${hasContactAccess ? 'Remove Client Contact' : 'Allow Client Contact'}
    </button>
  `;
}

function renderSettings() {
  const canUpdateMarkets = canMutate('markets.update');
  return `
    <section class="panel">
      <div class="panel-header">
        <div>
          <h2>Mobile App Controls</h2>
          <span>These settings decide what customers can book and what technicians can receive.</span>
        </div>
      </div>
      <div class="role-grid">
        <article class="mini-card">
          <strong>Markets & Countries</strong>
          <p>Enable or pause countries, currency, tax labels, support contacts, and payment providers.</p>
        </article>
        <article class="mini-card">
          <strong>Cities, Areas & Services</strong>
          <p>Control which services are active, coming soon, paused, or disabled for each city and area.</p>
        </article>
        <article class="mini-card">
          <strong>Business Modules</strong>
          <p>Managed Collection, Rental Property Listings, and future modules stay hidden while DISABLED, visible as COMING SOON, and bookable only when ACTIVE.</p>
          <p>Keep marketplace modules on COMING SOON until their app screens, review workflow, and launch rules are ready.</p>
        </article>
        <article class="mini-card">
          <strong>Call-out Fees</strong>
          <p>The default fee here is used by app booking flows unless a more specific service price is added later.</p>
        </article>
        <article class="mini-card">
          <strong>Technician Matching</strong>
          <p>Service keys in this section must match technician capability/category keys for dispatch to work cleanly.</p>
        </article>
      </div>
    </section>
    <div class="two-column settings-layout">
      <section class="panel">
        <div class="panel-header">
          <div>
            <h2>Configured Markets</h2>
            <span>Only countries MyFixer is operating in or preparing to launch.</span>
          </div>
        </div>
        <div class="settings-list">
          ${state.data.markets.map(renderMarketForm).join('') || renderEmpty('No configured markets yet.')}
        </div>
      </section>
      ${canUpdateMarkets ? `<section class="panel">
        <div class="panel-header">
          <div>
            <h2>Add Market</h2>
            <span>Add one country when MyFixer is ready to configure it.</span>
          </div>
        </div>
        ${renderAddMarketForm()}
      </section>` : ''}
    </div>
  `;
}

function renderAddMarketForm() {
  const availableMarkets = state.data.marketMeta.availableMarkets || [];
  const statuses = state.data.marketMeta.availableStatuses.length
    ? state.data.marketMeta.availableStatuses
    : ['COMING_SOON', 'ACTIVE', 'PAUSED', 'DISABLED'];

  if (!availableMarkets.length) {
    return `
      ${renderEmpty('All preloaded launch countries have been added. Use Custom Country for a country that is not listed yet.')}
      <form class="settings-form" onsubmit="saveMarket(event, '')">
        <input name="countryCode" type="hidden" value="__CUSTOM__" />
        <label>Country Code</label>
        <input name="customCountryCode" required placeholder="CI, SN, BW" />
        <label>Country Name</label>
        <input name="countryName" required placeholder="Country name" />
        <label>Status</label>
        <select name="status">
          ${statuses.map((status) => `<option value="${status}" ${status === 'COMING_SOON' ? 'selected' : ''}>${status}</option>`).join('')}
        </select>
        <div class="form-grid">
          <div>
            <label>Currency</label>
            <input name="currency" required placeholder="USD" />
          </div>
          <div>
            <label>Callout Fee</label>
            <input name="defaultCalloutFee" type="number" min="0" step="0.01" value="0" />
          </div>
          <div>
            <label>Commission %</label>
            <input name="commissionPercent" type="number" min="0" max="100" step="0.01" value="15" />
          </div>
          <div>
            <label>Support Phone</label>
            <input name="supportPhone" />
          </div>
        </div>
        ${renderCityServiceEditor([], state.data.marketMeta.defaultServiceCategories || [])}
        ${renderProviderEditor([])}
        <div class="form-grid">
          <div>
            <label>Support Email</label>
            <input name="supportEmail" type="email" />
          </div>
          <div>
            <label>WhatsApp</label>
            <input name="supportWhatsapp" />
          </div>
          <div>
            <label>Escalation Email</label>
            <input name="supportEscalationEmail" type="email" />
          </div>
        </div>
        <button class="primary-button" type="submit">Add Market</button>
      </form>
    `;
  }

  return `
    <form class="settings-form" onsubmit="saveMarket(event, '')">
      <p class="setting-help">Preloaded countries, including Zambia, are launch options from backend config. They are not client-bookable until saved here with ACTIVE country, city and service statuses.</p>
      <label>Country</label>
      <select name="countryCode" onchange="prefillMarketDefaults(this)">
        <option value="">Choose country</option>
        <option value="__CUSTOM__">Custom country not listed</option>
        ${availableMarkets.map((market) => {
          const marketView = getMarketView(market);
          return `
            <option
              value="${marketView.countryCode}"
              data-country-name="${escapeHtml(marketView.countryName)}"
              data-currency="${marketView.currency}"
              data-callout="${marketView.defaultCalloutFee}"
              data-commission="${marketView.platformCommissionBps / 100}"
              data-providers="${escapeHtml((marketView.paymentProviders || []).join(', '))}"
            >${escapeHtml(marketView.countryName)} (${escapeHtml(marketView.countryCode)}) - setup option</option>
          `;
        }).join('')}
      </select>
      <div class="custom-country-fields" data-custom-country-fields hidden>
        <label>Country Code</label>
        <input name="customCountryCode" placeholder="CI, SN, BW" />
        <label>Country Name</label>
        <input name="countryName" placeholder="Country name" />
      </div>
      <label>Status</label>
      <select name="status">
        ${statuses.map((status) => `<option value="${status}" ${status === 'COMING_SOON' ? 'selected' : ''}>${status}</option>`).join('')}
      </select>
      <div class="form-grid">
        <div>
          <label>Currency</label>
          <input name="currency" />
        </div>
        <div>
          <label>Callout Fee</label>
          <input name="defaultCalloutFee" type="number" min="0" step="0.01" />
        </div>
        <div>
          <label>Commission %</label>
          <input name="commissionPercent" type="number" min="0" max="100" step="0.01" />
        </div>
        <div>
          <label>Support Phone</label>
          <input name="supportPhone" />
        </div>
      </div>
      ${renderCityServiceEditor([], state.data.marketMeta.defaultServiceCategories || [])}
      ${renderProviderEditor([])}
      <div class="form-grid">
        <div>
          <label>Support Email</label>
          <input name="supportEmail" type="email" />
        </div>
        <div>
          <label>WhatsApp</label>
          <input name="supportWhatsapp" />
        </div>
        <div>
          <label>Escalation Email</label>
          <input name="supportEscalationEmail" type="email" />
        </div>
      </div>
      <button class="primary-button" type="submit">Add Market</button>
    </form>
  `;
}

function prefillMarketDefaults(select) {
  const option = select.selectedOptions[0];
  const form = select.closest('form');
  if (!option || !form) return;

  const isCustom = option.value === '__CUSTOM__';
  const customFields = form.querySelector('[data-custom-country-fields]');
  if (customFields) customFields.hidden = !isCustom;
  if (isCustom) {
    form.elements.currency.value = '';
    form.elements.defaultCalloutFee.value = '';
    form.elements.commissionPercent.value = '15';
    setProviderRows(form, []);
    return;
  }

  form.elements.countryName.value = option.dataset.countryName || '';
  form.elements.currency.value = option.dataset.currency || '';
  form.elements.defaultCalloutFee.value = option.dataset.callout || '';
  form.elements.commissionPercent.value = option.dataset.commission || '';
  setProviderRows(
    form,
    String(option.dataset.providers || '')
      .split(',')
      .map((provider, index) => ({
        provider: provider.trim(),
        status: index === 0 ? 'ACTIVE' : 'FALLBACK',
        methods: '',
        priority: index + 1,
        payoutEnabled: false,
        configReference: `${provider.trim()}_CONFIG_REF`,
      }))
      .filter((row) => row.provider)
  );
}

function renderCityServiceEditor(rows = [], defaultServices = [], disabled = false) {
  const normalizedRows = rows.length
    ? rows
    : [{ city: '', status: 'ACTIVE', services: normalizeServiceEntries(defaultServices) }];

  return `
    <details class="nested-settings" open>
      <summary>Cities & Services</summary>
      <p class="setting-help">Add cities and choose exactly which services are available in each city. COMING_SOON shows a non-bookable client card; ACTIVE requires super admin or service activation permission.</p>
      <div class="status-legend">
        <span class="status good">ACTIVE: bookable</span>
        <span class="status warn">COMING SOON: visible, not clickable</span>
        <span class="status warn">PAUSED: temporarily unavailable</span>
        <span class="status bad">DISABLED: hidden</span>
      </div>
      ${renderServiceDefinitionDatalist()}
      <div data-city-service-list>
        ${normalizedRows.map((row) => renderCityServiceRow(row, disabled)).join('')}
      </div>
      ${disabled ? '' : '<button class="ghost-button compact" type="button" onclick="addCityServiceRow(this)">Add another city</button>'}
    </details>
  `;
}

function renderCityServiceRow(row, disabled = false) {
  const disabledAttr = disabled ? 'disabled' : '';
  const services = normalizeServiceEntries(row.services, state.data.marketMeta.serviceDefinitions || []);
  const legacyServices = Array.isArray(row.services) && row.services.every((service) => typeof service === 'string')
    ? row.services.join(', ')
    : '';
  const areas = Array.isArray(row.areas) ? row.areas : [];
  const cityName = row.city || 'this city';
  const serviceCounts = countStatuses(services);
  const areaCounts = countStatuses(areas);
  return `
    <div class="city-service-card" data-city-service-row>
      <div class="city-service-header">
        <div>
          <span class="eyebrow">City configuration</span>
          <strong>${escapeHtml(cityName)}</strong>
          <div class="status-chip-row">
            <span class="status ${statusClass(row.status || 'ACTIVE')}">${escapeHtml(row.status || 'ACTIVE')}</span>
            ${statusSummaryPills(serviceCounts)}
            ${areas.length ? statusSummaryPills(areaCounts) : '<span class="status info">No areas</span>'}
          </div>
        </div>
        ${disabled ? '' : '<button class="danger-button compact" type="button" onclick="removeNestedRow(this)">Remove city</button>'}
      </div>
      <div class="city-row-grid">
        <label>City
          <input data-city placeholder="Johannesburg" value="${escapeHtml(row.city || '')}" ${disabledAttr} />
        </label>
        <label>City status
          <select data-city-status ${disabledAttr}>
            ${['ACTIVE', 'COMING_SOON', 'PAUSED', 'DISABLED'].map((status) => `<option value="${status}" ${status === row.status ? 'selected' : ''}>${status}</option>`).join('')}
          </select>
        </label>
        <label>Legacy services CSV
          <input data-city-services placeholder="Optional legacy fallback only" value="${escapeHtml(legacyServices)}" ${disabledAttr} />
        </label>
      </div>
      <div class="nested-section">
        <div class="nested-section-header">
          <strong>Services in ${escapeHtml(cityName)}</strong>
          ${disabled ? '' : `<button class="ghost-button compact" type="button" onclick="addServiceEntryRow(this)">Add service to ${escapeHtml(cityName)}</button>`}
        </div>
        <div class="service-entry-head">
          <span>Key</span><span>Display name</span><span>Status</span><span></span>
        </div>
        <div class="nested-sublist" data-service-entry-list>
          ${services.map((service) => renderServiceEntryRow(service, disabled)).join('') || renderServiceEntryRow({ serviceKey: '', label: '', status: 'ACTIVE' }, disabled)}
        </div>
      </div>
      <div class="nested-section">
        <div class="nested-section-header">
          <strong>Areas in ${escapeHtml(cityName)}</strong>
          ${disabled ? '' : `<button class="ghost-button compact" type="button" onclick="addAreaEntryRow(this)">Add area to ${escapeHtml(cityName)}</button>`}
        </div>
        <div class="area-entry-head">
          <span>Area</span><span>Status</span><span>Area-level service overrides</span><span></span>
        </div>
        <div class="nested-sublist" data-area-entry-list>
          ${areas.map((area) => renderAreaEntryRow(area, disabled)).join('') || '<p class="setting-help tight">No area overrides. The city service statuses apply everywhere in this city.</p>'}
        </div>
      </div>
    </div>
  `;
}

function renderServiceEntryRow(service, disabled = false) {
  const disabledAttr = disabled ? 'disabled' : '';
  const serviceKey = serviceKeyFrom(service.serviceKey || service.label || '');
  const label = service.label || labelFromServiceKey(serviceKey);
  return `
    <div class="nested-row service-entry-row" data-service-entry-row>
      <input data-service-key list="service-key-options" placeholder="service_key" value="${escapeHtml(serviceKey)}" ${disabledAttr} />
      <input data-service-label placeholder="Display label" value="${escapeHtml(label)}" ${disabledAttr} />
      <select data-service-status ${disabledAttr}>
        ${['ACTIVE', 'COMING_SOON', 'PAUSED', 'DISABLED'].map((status) => `<option value="${status}" ${status === service.status ? 'selected' : ''}>${status}</option>`).join('')}
      </select>
      ${disabled ? '' : '<button class="danger-button compact" type="button" onclick="removeNestedRow(this)">Remove</button>'}
    </div>
  `;
}

function renderServiceDefinitionDatalist() {
  const definitions = normalizeServiceEntries(state.data.marketMeta.serviceDefinitions || []);
  return `
    <datalist id="service-key-options">
      ${definitions.map((service) => `<option value="${escapeHtml(service.serviceKey)}">${escapeHtml(service.label)}</option>`).join('')}
    </datalist>
  `;
}

function renderAreaEntryRow(area, disabled = false) {
  const disabledAttr = disabled ? 'disabled' : '';
  return `
    <div class="nested-row area-entry-row" data-area-entry-row>
      <input data-area-name placeholder="Area / Neighbourhood" value="${escapeHtml(area.name || '')}" ${disabledAttr} />
      <select data-area-status ${disabledAttr}>
        ${['ACTIVE', 'COMING_SOON', 'PAUSED', 'DISABLED'].map((status) => `<option value="${status}" ${status === area.status ? 'selected' : ''}>${status}</option>`).join('')}
      </select>
      <input data-area-services placeholder="appliance_repair:ACTIVE, cleaning:COMING_SOON" value="${escapeHtml(formatServiceList(area.services || []))}" ${disabledAttr} />
      ${disabled ? '' : '<button class="danger-button compact" type="button" onclick="removeNestedRow(this)">Remove</button>'}
    </div>
  `;
}

function renderProviderEditor(rows = [], disabled = false) {
  const normalizedRows = rows.length
    ? rows
    : [{ provider: '', status: 'DISABLED', methods: '', priority: 1, payoutEnabled: false, configReference: '' }];

  return `
    <details class="nested-settings" open>
      <summary>Payment Providers</summary>
      <p class="setting-help">Configure collection/payout providers without storing raw secret keys in the portal.</p>
      <div data-provider-list>
        ${normalizedRows.map((row) => renderProviderRow(row, disabled)).join('')}
      </div>
      ${disabled ? '' : '<button class="ghost-button compact" type="button" onclick="addProviderRow(this)">Add Provider</button>'}
    </details>
  `;
}

function renderProviderRow(row, disabled = false) {
  const methods = Array.isArray(row.methods) ? row.methods.join(', ') : row.methods || '';
  const disabledAttr = disabled ? 'disabled' : '';
  return `
    <div class="nested-row provider-row" data-provider-row>
      <input data-provider placeholder="PAYSTACK" value="${escapeHtml(row.provider || '')}" ${disabledAttr} />
      <select data-provider-status ${disabledAttr}>
        ${['ACTIVE', 'FALLBACK', 'TESTING', 'DISABLED'].map((status) => `<option value="${status}" ${status === row.status ? 'selected' : ''}>${status}</option>`).join('')}
      </select>
      <input data-provider-methods placeholder="card, bank, mobile_money" value="${escapeHtml(methods)}" ${disabledAttr} />
      <input data-provider-priority type="number" min="1" value="${row.priority || 1}" ${disabledAttr} />
      <label class="inline-check"><input data-provider-payout type="checkbox" ${row.payoutEnabled ? 'checked' : ''} ${disabledAttr} /> Payout</label>
      <input data-provider-config placeholder="PAYSTACK_CONFIG_REF" value="${escapeHtml(row.configReference || '')}" ${disabledAttr} />
      ${disabled ? '' : '<button class="danger-button compact" type="button" onclick="removeNestedRow(this)">Remove</button>'}
    </div>
  `;
}

function addCityServiceRow(button) {
  const list = button.closest('.nested-settings')?.querySelector('[data-city-service-list]');
  if (!list) return;
  list.insertAdjacentHTML('beforeend', renderCityServiceRow({ city: '', status: 'ACTIVE', services: [] }));
}

function addServiceEntryRow(button) {
  const list = button.closest('[data-city-service-row]')?.querySelector('[data-service-entry-list]');
  if (!list) return;
  list.insertAdjacentHTML('beforeend', renderServiceEntryRow({ serviceKey: '', label: '', status: 'ACTIVE' }));
}

function addAreaEntryRow(button) {
  const list = button.closest('[data-city-service-row]')?.querySelector('[data-area-entry-list]');
  if (!list) return;
  list.insertAdjacentHTML('beforeend', renderAreaEntryRow({ name: '', status: 'ACTIVE', services: [] }));
}

function addProviderRow(button) {
  const list = button.closest('.nested-settings')?.querySelector('[data-provider-list]');
  if (!list) return;
  const priority = list.querySelectorAll('[data-provider-row]').length + 1;
  list.insertAdjacentHTML('beforeend', renderProviderRow({ provider: '', status: 'DISABLED', methods: '', priority, payoutEnabled: false, configReference: '' }));
}

function removeNestedRow(button) {
  button.closest('.nested-row, .city-service-card')?.remove();
}

function setProviderRows(form, rows) {
  const list = form.querySelector('[data-provider-list]');
  if (!list) return;
  list.innerHTML = rows.length
    ? rows.map(renderProviderRow).join('')
    : renderProviderRow({ provider: '', status: 'DISABLED', methods: '', priority: 1, payoutEnabled: false, configReference: '' });
}

function renderMarketForm(market) {
  const marketView = getMarketView(market);
  const canUpdateMarkets = canMutate('markets.update');
  const disabled = canUpdateMarkets ? '' : 'disabled';
  const statuses = state.data.marketMeta.availableStatuses.length
    ? state.data.marketMeta.availableStatuses
    : ['COMING_SOON', 'ACTIVE', 'PAUSED', 'DISABLED'];
  const commissionPercent = (marketView.platformCommissionBps / 100).toFixed(2);

  return `
    <form class="market-card" onsubmit="saveMarket(event, '${marketView.countryCode}')">
      <input name="countryName" type="hidden" value="${escapeHtml(marketView.countryName)}" />
      <input name="taxLabel" type="hidden" value="${escapeHtml(marketView.taxLabel)}" />
      <input name="supportWhatsapp" type="hidden" value="${escapeHtml(marketView.supportWhatsapp)}" />
      <input name="supportEscalationEmail" type="hidden" value="${escapeHtml(marketView.supportEscalationEmail)}" />
      <div class="market-card-header">
        <div>
          <strong>${escapeHtml(marketView.countryName)} (${escapeHtml(marketView.countryCode)})</strong>
          <span>${escapeHtml(marketView.currency)} - ${marketView.hasCustomSettings ? 'custom settings' : 'default config'}${marketView.status === 'DISABLED' ? ' - not visible to clients' : ''}</span>
        </div>
        <span class="status ${statusClass(marketView.status)}">${escapeHtml(marketView.status || (marketView.enabled ? 'ACTIVE' : 'DISABLED'))}</span>
      </div>
      ${marketStatusSummary(marketView)}
      <div class="form-grid">
        <div>
          <label>Status</label>
          <select name="status" ${disabled}>
            ${statuses.map((status) => `<option value="${status}" ${status === marketView.status ? 'selected' : ''}>${status}</option>`).join('')}
          </select>
        </div>
        <div>
          <label>Currency</label>
          <input name="currency" value="${escapeHtml(marketView.currency)}" ${disabled} />
        </div>
        <div>
          <label>Callout Fee</label>
          <input name="defaultCalloutFee" type="number" min="0" step="0.01" value="${marketView.defaultCalloutFee}" ${disabled} />
        </div>
        <div>
          <label>Commission %</label>
          <input name="commissionPercent" type="number" min="0" max="100" step="0.01" value="${commissionPercent}" ${disabled} />
        </div>
      </div>
      ${renderCityServiceEditor(marketView.cityServiceAvailability || [], marketView.serviceCategories || state.data.marketMeta.defaultServiceCategories || [], !canUpdateMarkets)}
      ${renderProviderEditor(marketView.providerSettings || [], !canUpdateMarkets)}
      <div class="form-grid">
        <div>
          <label>Support Email</label>
          <input name="supportEmail" value="${escapeHtml(marketView.supportEmail)}" ${disabled} />
        </div>
        <div>
          <label>Support Phone</label>
          <input name="supportPhone" value="${escapeHtml(marketView.supportPhone)}" ${disabled} />
        </div>
      </div>
      ${canUpdateMarkets ? '<button class="primary-button compact" type="submit">Save Market</button>' : '<span class="status info">Read only</span>'}
    </form>
  `;
}

function renderAuditLogs() {
  return `
    <section class="panel">
      <div class="panel-header"><h2>Audit Logs</h2><span>${state.data.auditLogs.length} latest</span></div>
      ${renderGenericTable(state.data.auditLogs, ['Action', 'Actor', 'Resource', 'Metadata', 'Created'], (log) => {
        const action = log.event?.action || log.action || '-';
        const actorEmail = log.actor?.email || log.actorEmail || '-';
        const resourceType = log.event?.resourceType || log.resourceType || '-';
        const resourceId = log.event?.resourceId || log.resourceId || '-';
        return [
          escapeHtml(action),
          escapeHtml(actorEmail),
          `${escapeHtml(resourceType)}<span>${escapeHtml(resourceId)}</span>`,
          `<code>${escapeHtml(JSON.stringify(log.metadata || {}))}</code>`,
          formatDate(log.createdAt),
        ];
      })}
    </section>
  `;
}

function renderGenericTable(rows, headers, mapRow) {
  if (!rows.length) return renderEmpty('No records found.');
  return `
    <div class="table-wrap">
      <table>
        <thead><tr>${headers.map((header) => `<th>${header}</th>`).join('')}</tr></thead>
        <tbody>
          ${rows.map((row) => `<tr>${mapRow(row).map((cell) => `<td>${cell}</td>`).join('')}</tr>`).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function renderEmpty(message) {
  return `<p class="empty"><span>No data</span>${escapeHtml(message)}</p>`;
}

function mediaById(media = []) {
  return new Map(media.map((item) => [String(item._id || item.id), item]));
}

function renderMediaGallery(media = []) {
  if (!media.length) return renderEmpty('No images have been uploaded for this booking yet.');
  return `
    <div class="media-gallery">
      ${media.map((item) => `
        <a class="media-tile" href="${escapeHtml(item.url)}" target="_blank" rel="noopener noreferrer">
          <img src="${escapeHtml(item.thumbnailUrl || item.url)}" alt="${escapeHtml(item.purpose || 'Job image')}" />
          <span class="status ${statusClass(item.purpose)}">${escapeHtml(item.purpose || 'IMAGE')}</span>
          <small>${escapeHtml(item.uploadedByRole || 'UNKNOWN')} - ${formatDate(item.createdAt)}</small>
        </a>
      `).join('')}
    </div>
  `;
}

function renderChatLog(messages = [], media = []) {
  if (!messages.length) return renderEmpty('No chat messages have been saved for this booking yet.');
  const lookup = mediaById(media);

  return `
    <div class="chat-log">
      ${messages.map((message) => {
        const attachedMedia = (message.mediaIds || [])
          .map((id) => lookup.get(String(id)))
          .filter(Boolean);
        return `
          <article class="chat-row ${message.senderRole === 'CUSTOMER' ? 'customer' : 'provider'}">
            <div class="chat-row-header">
              <strong>${escapeHtml(message.senderRole || 'UNKNOWN')}</strong>
              <span>${formatDate(message.createdAt)}</span>
            </div>
            ${message.text ? `<p>${escapeHtml(message.text)}</p>` : ''}
            ${attachedMedia.length ? renderMediaGallery(attachedMedia) : ''}
          </article>
        `;
      }).join('')}
    </div>
  `;
}

function renderBookingDrawer() {
  const data = state.selectedBooking;
  const booking = data.booking;
  const countryCode = booking.identity?.countryCode || booking.countryCode || '-';
  const currency = booking.identity?.currency || booking.currency || 'ZAR';
  const media = data.media || [];
  const messages = data.messages || [];
  const participants = data.participants || {};
  const technician = participants.technician || {};
  const customer = participants.customer || {};
  const proofMedia = media.filter((item) => String(item.purpose || '').includes('PROOF') || String(item.purpose || '').includes('AFTER'));
  return `
    <aside class="drawer">
      <div class="drawer-header">
        <div>
          <span class="eyebrow">Booking detail</span>
          <h2>${escapeHtml(booking.applianceType)}</h2>
        </div>
        <button class="ghost-button compact" onclick="state.selectedBooking=null; render()">Close</button>
      </div>
      <div class="drawer-body">
        <div class="detail-grid">
          <div><span>Status</span><strong>${escapeHtml(booking.status)}</strong></div>
          <div><span>Customer</span><strong>${escapeHtml(booking.customerName)}</strong></div>
          <div><span>Market</span><strong>${escapeHtml(countryCode)} - ${escapeHtml(currency)}</strong></div>
          <div><span>Callout</span><strong>${getMoney(booking, 'price', 'priceMinor', currency)}</strong></div>
        </div>
        <h3>Address</h3>
        <p>${escapeHtml(booking.fullAddress || '-')} ${escapeHtml(booking.complexDetails || '')}</p>
        <h3>Fault</h3>
        <p>${escapeHtml(booking.faultDescription || '-')}</p>
        <h3>People Involved</h3>
        <div class="participant-grid">
          <article class="participant-card">
            <div class="participant-avatar">${customer.profilePhotoUrl ? `<img src="${escapeHtml(customer.profilePhotoUrl)}" alt="Customer" />` : 'C'}</div>
            <div>
              <strong>${escapeHtml(customer.name || booking.customerName || 'Customer')}</strong>
              <p>${escapeHtml(customer.email || '')}</p>
              <p>${escapeHtml(customer.phone || '')}</p>
            </div>
          </article>
          <article class="participant-card">
            <div class="participant-avatar">${technician.profilePhotoUrl ? `<img src="${escapeHtml(technician.profilePhotoUrl)}" alt="Technician" />` : 'T'}</div>
            <div>
              <strong>${escapeHtml(technician.name || 'Assigned technician')}</strong>
              <p>${escapeHtml(technician.email || '')}</p>
              <p>${escapeHtml(technician.phone || '')}</p>
              <span class="status ${technician.photoStatus === 'VERIFIED' ? 'success' : 'info'}">Photo ${escapeHtml(technician.photoStatus || 'NOT_SUBMITTED')}</span>
            </div>
          </article>
        </div>
        <h3>Uploaded Images</h3>
        ${renderMediaGallery(media)}
        <h3>Completion Proof</h3>
        ${renderMediaGallery(proofMedia)}
        <h3>Chat History</h3>
        ${renderChatLog(messages, media)}
        <h3>Quotes</h3>
        ${renderGenericTable(data.quotes || [], ['Status', 'Total', 'Items'], (quote) => [
          `<span class="status ${statusClass(quote.status)}">${escapeHtml(quote.status)}</span>`,
          getMoney(quote, 'totalAmount', 'totalAmountMinor', quote.currency),
          quote.lineItems?.length || 0,
        ])}
        <h3>Ledger</h3>
        ${renderGenericTable(data.ledger || [], ['Type', 'Amount', 'Status'], (row) => [
          escapeHtml(row.type),
          getMoney(row, 'amount', 'amountMinor', row.currency),
          `<span class="status ${statusClass(row.status)}">${escapeHtml(row.status)}</span>`,
        ])}
      </div>
    </aside>
  `;
}

function render() {
  if (!state.token) {
    renderLogin();
    return;
  }
  renderShell();
}

window.login = login;
window.forgotPassword = forgotPassword;
window.resetPassword = resetPassword;
window.changePassword = changePassword;
window.setAuthView = setAuthView;
window.logout = logout;
window.refresh = refresh;
window.setView = setView;
window.revealClientContact = revealClientContact;
window.hideClientContact = hideClientContact;
window.reviewTechnician = reviewTechnician;
window.openBooking = openBooking;
window.updateManagedCollectionReminder = updateManagedCollectionReminder;
window.rescheduleManagedCollectionReminder = rescheduleManagedCollectionReminder;
window.updateCollectionJob = updateCollectionJob;
window.markCollectionCompleted = markCollectionCompleted;
window.markCollectionMissed = markCollectionMissed;
window.rescheduleCollectionJob = rescheduleCollectionJob;
window.cancelCollectionJob = cancelCollectionJob;
window.applyCollectionOperationFilters = applyCollectionOperationFilters;
window.resetCollectionOperationFilters = resetCollectionOperationFilters;
window.applyNotificationFilters = applyNotificationFilters;
window.resetNotificationFilters = resetNotificationFilters;
window.processDueNotifications = processDueNotifications;
window.retryNotification = retryNotification;
window.cancelNotification = cancelNotification;
window.createSubscriptionPlan = createSubscriptionPlan;
window.generateSubscriptionInvoices = generateSubscriptionInvoices;
window.createPromotion = createPromotion;
window.updatePromotion = updatePromotion;
window.saveMarket = saveMarket;
window.createAdminUser = createAdminUser;
window.updateAdminUser = updateAdminUser;
window.prefillMarketDefaults = prefillMarketDefaults;
window.addCityServiceRow = addCityServiceRow;
window.addServiceEntryRow = addServiceEntryRow;
window.addAreaEntryRow = addAreaEntryRow;
window.addProviderRow = addProviderRow;
window.removeNestedRow = removeNestedRow;
window.state = state;
window.render = render;

setupIdleSecurity();

if (state.token && state.user?.mustChangePassword) {
  state.authView = 'changePassword';
  render();
} else if (state.token) {
  loadAllData().catch(() => {
    state.token = '';
    localStorage.removeItem('myfixer_admin_token');
  }).finally(() => {
    resetIdleTimer();
    render();
  });
} else {
  render();
}
